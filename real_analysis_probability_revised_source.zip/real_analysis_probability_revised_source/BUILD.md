# 编译说明

请在源码包根目录使用 XeLaTeX。完整 TeX Live 环境可连续运行三次：

```sh
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

若系统没有安装包内附带的 CTeX/xeCJK 版本，可让 TeX 同时递归搜索 `localtexmf`：

```sh
TEXINPUTS=.:localtexmf/tex//: xelatex -interaction=nonstopmode -halt-on-error main.tex
```

再重复后一个命令两次，使目录、书签与交叉引用收敛。包内的
`localtexmf/fonts/opentype/public/notocjk` 含正文所用的 Noto Sans CJK SC 字体。
最终审稿时的参考输出为 953 个 A4 物理页；第 7--8 章合计 419 个正文页。
