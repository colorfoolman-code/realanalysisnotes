# 编译说明

本源码包包含全书第 1--7 章，并已合入完成修订的第 1 章与第 2 章；不附带字体文件。

第 2 章是在原讲义基础上修订：保留原讲义内容，并整合补充计划中的正式数学内容；路线图、对比表、位置/状态、先修回顾、依赖清单、篇幅边界等编辑检查性模板未写入正文。修订中补足了相关定义、定理、命题、证明、计算、反例、例子及章节间的数学性承接。

建议环境：TeX Live（含 XeLaTeX、latexmk、Fandol 与 Latin Modern 字体）。在源码根目录运行：

```bash
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

如需清理编译产物：

```bash
latexmk -C
```
