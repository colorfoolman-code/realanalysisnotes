import type { Block, Chapter, Notes, Preface, Section, Subsection } from '../content/types';
import { BLOCK_NAMES } from '../content/types';

export interface TexFile {
  name: string;
  content: string;
}

const ROOT = '00-master-plan.tex';

function header(): string {
  return `% !TeX root = ${ROOT}\n`;
}

function itemLabel(b: Block): string {
  switch (b.kind) {
    case 'build':
      return b.label ? `${b.label}${b.title ? '：' + b.title : ''}` : b.title ?? BLOCK_NAMES.build;
    case 'example':
      return `例 ${b.label ?? ''}${b.title ? '：' + b.title : ''}`.trim();
    case 'counter':
      return `反例 ${b.label ?? ''}${b.title ? '：' + b.title : ''}`.trim();
    default:
      return b.title ? `${BLOCK_NAMES[b.kind]}：${b.title}` : BLOCK_NAMES[b.kind];
  }
}

const CN_ENUM = /（[一二三四五六七八九十]+）/g;

// “初学者易错点”段落写成“（一）…（二）…”，LaTeX 中排成 enumerate，每条一行。
function renderEnumerated(p: string): string {
  const parts = p.split(CN_ENUM).map((s) => s.trim()).filter(Boolean);
  if (parts.length < 2) return p;
  return ['\\begin{enumerate}[label=（\\chinese*）,leftmargin=2.2em,itemsep=0.15em]', ...parts.map((s) => `\\item ${s}`), '\\end{enumerate}'].join('\n');
}

function renderBlock(b: Block): string {
  const label = itemLabel(b);
  const body = b.paras.map((p) => (b.kind === 'pitfall' ? renderEnumerated(p) : p)).join('\n\n');
  return `\\item[{${label}}]\n${body}\n`;
}

function renderSubsection(s: Subsection): string {
  const lines: string[] = [];
  const statusNote =
    s.status === '保留并慢化'
      ? `保留并慢化；原 label \\texttt{${s.origLabel ?? s.label}}`
      : s.status === '前移'
        ? `原 \\texttt{${s.origLabel}} 整体前移；新 label \\texttt{${s.label}}，旧 label 以 \\texttt{\\string\\subsectionalias} 保留`
        : `${s.status}；建议正文 label \\texttt{${s.label}}`;
  if (s.status === '保留并慢化') {
    lines.push(`\\subsection*{${s.number}\\quad ${s.title}}`);
    lines.push(`\\addcontentsline{toc}{subsection}{${s.number}\\quad ${s.title}}`);
    lines.push(`\\label{plan:${s.origLabel ?? s.label}}`);
  } else {
    lines.push(`\\insertedsubsection{${s.number}}{${s.title}}{plan:${s.label}}`);
  }
  lines.push(`\\noindent\\textit{${statusNote}；建议篇幅约 ${s.pages} 页。}`);
  lines.push('');
  lines.push('\\begin{description}');
  for (const b of s.blocks) lines.push(renderBlock(b));
  lines.push('\\end{description}');
  lines.push('');
  return lines.join('\n');
}

function renderSection(sec: Section): string {
  const lines: string[] = [];
  lines.push(`\\section*{${sec.number}\\quad ${sec.title}${sec.isNew ? '（新增二级节）' : ''}}`);
  lines.push(`\\addcontentsline{toc}{section}{${sec.number}\\quad ${sec.title}}`);
  lines.push('');
  for (const p of sec.lead) lines.push(p + '\n');
  for (const sub of sec.subsections) lines.push(renderSubsection(sub));
  return lines.join('\n');
}

export function renderChapter(ch: Chapter): string {
  const lines: string[] = [header()];
  lines.push(`\\chapter{${ch.title}}`);
  lines.push(`\\label{plan:chapter-${ch.number}}`);
  lines.push('');
  lines.push('\\section*{章主线}');
  for (const p of ch.thread) lines.push(p + '\n');
  for (const sec of ch.sections) lines.push(renderSection(sec));
  lines.push('\\section*{章末衔接}');
  for (const p of ch.closing) lines.push(p + '\n');
  return lines.join('\n');
}

export function renderPreface(p: Preface): string {
  const lines: string[] = [header()];
  lines.push('\\chapter*{总纲}');
  lines.push('\\addcontentsline{toc}{chapter}{总纲}');
  lines.push('');
  for (const para of p.paras) lines.push(para + '\n');
  lines.push('\\section*{先修清单}');
  for (const g of p.prerequisites) {
    lines.push(`\\paragraph{${g.title}}`);
    lines.push('\\begin{itemize}');
    for (const it of g.items) lines.push(`\\item ${it}`);
    lines.push('\\end{itemize}');
  }
  for (const t of p.threads) {
    lines.push(`\\section*{${t.title}}`);
    for (const para of t.paras) lines.push(para + '\n');
  }
  lines.push('\\section*{写作与编号约定}');
  lines.push('\\begin{itemize}');
  for (const c of p.conventions) lines.push(`\\item ${c}`);
  lines.push('\\end{itemize}');
  lines.push('');
  return lines.join('\n');
}

export function renderNotes(n: Notes): string {
  const lines: string[] = [header()];
  lines.push(`\\chapter*{${n.title}}`);
  lines.push(`\\addcontentsline{toc}{chapter}{${n.title}}`);
  lines.push(`\\noindent\\textit{${n.subtitle}}`);
  lines.push('');
  for (const s of n.sections) {
    lines.push(`\\section*{${s.title}}`);
    for (const para of s.paras) lines.push(para + '\n');
    if (s.bullets && s.bullets.length) {
      lines.push('\\begin{itemize}');
      for (const b of s.bullets) lines.push(`\\item ${b}`);
      lines.push('\\end{itemize}');
      lines.push('');
    }
  }
  return lines.join('\n');
}

export function renderMaster(p: Preface, chapters: Chapter[]): string {
  const inputs = ['\\input{00-preface}', '\\input{00-revision-notes}', ...chapters.map((c) => `\\input{${c.file.replace(/\.tex$/, '')}}`)].join('\n');
  return `% ${ROOT} —— 使用 XeLaTeX 编译
\\documentclass[a4paper,11pt,openany]{ctexbook}
\\usepackage{amsmath,amssymb,amsthm}
\\usepackage{enumitem}
\\usepackage{geometry}
\\geometry{margin=2.4cm}
\\usepackage[colorlinks,linkcolor=blue!50!black]{hyperref}
\\setlist[description]{style=nextline,leftmargin=1.2em,itemsep=0.5em}
\\setlist[itemize]{itemsep=0.3em}

% 若主文档已定义下列命令，删除此处的定义。
\\providecommand{\\insertedsubsection}[3]{%
  \\phantomsection
  \\subsection*{#1\\quad #2}%
  \\addcontentsline{toc}{subsection}{#1\\quad #2}%
  \\label{#3}}
\\providecommand{\\subsectionalias}[1]{\\label{#1}}

\\title{${p.title}\\\\[0.6em]\\large ${p.subtitle}}
\\author{}
\\date{}

\\begin{document}
\\maketitle
\\tableofcontents

${inputs}

\\end{document}
`;
}

export function buildTexFiles(p: Preface, notes: Notes, chapters: Chapter[]): TexFile[] {
  return [
    { name: ROOT, content: renderMaster(p, chapters) },
    { name: '00-preface.tex', content: renderPreface(p) },
    { name: '00-revision-notes.tex', content: renderNotes(notes) },
    ...chapters.map((c) => ({ name: c.file, content: renderChapter(c) })),
  ];
}
