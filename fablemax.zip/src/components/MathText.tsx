import { useMemo } from 'react';
import katex from 'katex';
import 'katex/dist/katex.min.css';

type Segment = { type: 'text' | 'inline' | 'display'; value: string };

function splitSegments(src: string): Segment[] {
  const out: Segment[] = [];
  let i = 0;
  let buf = '';
  const flush = () => {
    if (buf) out.push({ type: 'text', value: buf });
    buf = '';
  };
  while (i < src.length) {
    if (src.startsWith('\\[', i)) {
      const end = src.indexOf('\\]', i + 2);
      if (end !== -1) {
        flush();
        out.push({ type: 'display', value: src.slice(i + 2, end) });
        i = end + 2;
        continue;
      }
    }
    if (src[i] === '$') {
      const end = src.indexOf('$', i + 1);
      if (end !== -1) {
        flush();
        out.push({ type: 'inline', value: src.slice(i + 1, end) });
        i = end + 1;
        continue;
      }
    }
    buf += src[i];
    i += 1;
  }
  flush();
  return out;
}

// 少量文本宏在网页中转成可读形式
function cleanText(t: string): string {
  return t
    .replace(/\\texttt\{((?:\\[{}]|[^{}])*)\}/g, '$1')
    .replace(/\\textit\{((?:\\[{}]|[^{}])*)\}/g, '$1')
    .replace(/\\emph\{((?:\\[{}]|[^{}])*)\}/g, '$1')
    .replace(/\\string\\/g, '\\')
    .replace(/\\\{/g, '{')
    .replace(/\\\}/g, '}')
    .replace(/\\\\/g, '\\');
}

function renderMath(tex: string, display: boolean): string {
  try {
    return katex.renderToString(tex, { displayMode: display, throwOnError: false, strict: 'ignore' });
  } catch {
    return `<code>${tex}</code>`;
  }
}

export function MathText({ text, className, as = 'p' }: { text: string; className?: string; as?: 'p' | 'span' }) {
  const html = useMemo(() => {
    return splitSegments(text)
      .map((s) => {
        if (s.type === 'text') return escapeHtml(cleanText(s.value));
        return renderMath(s.value, s.type === 'display');
      })
      .join('');
  }, [text]);
  if (as === 'span') return <span className={className} dangerouslySetInnerHTML={{ __html: html }} />;
  return <p className={className} dangerouslySetInnerHTML={{ __html: html }} />;
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
