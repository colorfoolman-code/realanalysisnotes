import { chapters, countSubsections, preface } from '../content';
import { MathText } from './MathText';

export function PrefaceView({ onOpenChapter }: { onOpenChapter: (id: string) => void }) {
  const totals = chapters.map(countSubsections);
  const sum = totals.reduce(
    (a, c) => ({
      total: a.total + c.total,
      kept: a.kept + c.kept,
      added: a.added + c.added,
      topics: a.topics + c.topics,
      pages: a.pages + c.pages,
      examples: a.examples + c.examples,
      counters: a.counters + c.counters,
    }),
    { total: 0, kept: 0, added: 0, topics: 0, pages: 0, examples: 0, counters: 0 },
  );
  return (
    <div className="mx-auto max-w-4xl space-y-10 px-4 py-10 sm:px-8">
      <header className="space-y-4">
        <div className="text-xs font-semibold uppercase tracking-widest text-slate-400">总纲</div>
        <h1 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">{preface.title}</h1>
        <p className="text-lg text-slate-600">{preface.subtitle}</p>
        <div className="space-y-3 pt-2">
          {preface.paras.map((p, i) => (
            <MathText key={i} text={p} className="text-[15px] leading-7 text-slate-700" />
          ))}
        </div>
      </header>

      <section className="grid gap-4 sm:grid-cols-3">
        {chapters.map((ch, i) => (
          <button
            key={ch.number}
            onClick={() => onOpenChapter(`ch${ch.number}`)}
            className="group rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
          >
            <div className="text-xs font-semibold uppercase tracking-widest text-slate-400">Chapter {ch.number}</div>
            <div className="mt-1 text-base font-semibold text-slate-900 group-hover:text-slate-700">{ch.short}</div>
            <div className="mt-3 space-y-1 text-xs text-slate-500">
              <div>三级节 {totals[i].total}（原节 {totals[i].kept} · 新增 {totals[i].added} · 新增主题 {totals[i].topics}）</div>
              <div>参考篇幅约 {totals[i].pages} 页</div>
            </div>
          </button>
        ))}
      </section>
      <p className="text-sm text-slate-500">
        三章合计 {sum.total} 个三级节：原节 {sum.kept} 个全部保留，新增 {sum.added} 个，新增主题 {sum.topics} 个；参考篇幅约 {sum.pages} 页；例 {sum.examples} 组、反例 {sum.counters} 组。
      </p>

      <section className="rounded-2xl border border-teal-200 bg-teal-50/40 p-6 sm:p-8">
        <h2 className="mb-4 text-lg font-semibold text-slate-900">先修清单</h2>
        <div className="space-y-4">
          {preface.prerequisites.map((g) => (
            <div key={g.title}>
              <div className="mb-1 text-sm font-semibold text-teal-800">{g.title}</div>
              <ul className="list-disc space-y-1 pl-5">
                {g.items.map((it, i) => (
                  <li key={i}>
                    <MathText text={it} className="text-[15px] leading-7 text-slate-700" />
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {preface.threads.map((t) => (
        <section key={t.title} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
          <h2 className="mb-3 text-lg font-semibold text-slate-900">{t.title}</h2>
          <div className="space-y-3">
            {t.paras.map((p, i) => (
              <MathText key={i} text={p} className="text-[15px] leading-7 text-slate-700" />
            ))}
          </div>
        </section>
      ))}

      <section className="rounded-2xl border border-slate-200 bg-slate-50 p-6 sm:p-8">
        <h2 className="mb-3 text-lg font-semibold text-slate-900">写作与编号约定</h2>
        <ul className="list-disc space-y-2 pl-5">
          {preface.conventions.map((c, i) => (
            <li key={i}>
              <MathText text={c} className="text-[15px] leading-7 text-slate-700" />
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
