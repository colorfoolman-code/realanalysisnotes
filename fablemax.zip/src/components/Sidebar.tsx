import { chapters, countSubsections } from '../content';
import type { SubStatus } from '../content/types';
import { cn } from '../utils/cn';
import { MathText } from './MathText';

export const STATUS_STYLE: Record<SubStatus, string> = {
  新增: 'bg-emerald-100 text-emerald-800 ring-emerald-200',
  新增主题: 'bg-violet-100 text-violet-800 ring-violet-200',
  保留并慢化: 'bg-slate-100 text-slate-700 ring-slate-200',
  前移: 'bg-amber-100 text-amber-800 ring-amber-200',
};

export function StatusBadge({ status, small }: { status: SubStatus; small?: boolean }) {
  return (
    <span
      className={cn(
        'inline-flex shrink-0 items-center rounded-full font-medium ring-1 ring-inset',
        small ? 'px-1.5 py-0 text-[10px]' : 'px-2 py-0.5 text-xs',
        STATUS_STYLE[status],
      )}
    >
      {status}
    </span>
  );
}

interface Props {
  view: string; // 'preface' | 'latex' | chapter id
  onSelect: (view: string, anchor?: string) => void;
  onClose?: () => void;
}

export function Sidebar({ view, onSelect, onClose }: Props) {
  return (
    <nav className="flex h-full flex-col overflow-y-auto bg-white/80 backdrop-blur">
      <div className="border-b border-slate-200 px-5 py-4">
        <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">实分析讲义</div>
        <div className="mt-1 text-base font-semibold text-slate-900">三章补充计划 · 第二版</div>
      </div>
      <div className="px-3 py-3">
        <button
          onClick={() => {
            onSelect('preface');
            onClose?.();
          }}
          className={cn(
            'w-full rounded-lg px-3 py-2 text-left text-sm font-medium transition',
            view === 'preface' ? 'bg-slate-900 text-white' : 'text-slate-700 hover:bg-slate-100',
          )}
        >
          总纲：主线与贯穿对象
        </button>
        <button
          onClick={() => {
            onSelect('notes');
            onClose?.();
          }}
          className={cn(
            'mt-1 w-full rounded-lg px-3 py-2 text-left text-sm font-medium transition',
            view === 'notes' ? 'bg-slate-900 text-white' : 'text-slate-700 hover:bg-slate-100',
          )}
        >
          第二次修订说明：诊断与依赖审核
        </button>
      </div>
      {chapters.map((ch) => {
        const id = `ch${ch.number}`;
        const c = countSubsections(ch);
        const active = view === id;
        return (
          <div key={id} className="border-t border-slate-100 px-3 py-3">
            <button
              onClick={() => {
                onSelect(id);
                onClose?.();
              }}
              className={cn(
                'flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm font-semibold transition',
                active ? 'bg-slate-900 text-white' : 'text-slate-800 hover:bg-slate-100',
              )}
            >
              <span>{ch.short}</span>
              <span className={cn('text-xs font-normal', active ? 'text-slate-300' : 'text-slate-400')}>
                {c.total} 节
              </span>
            </button>
            <ul className="mt-2 space-y-0.5">
              {ch.sections.map((sec) => (
                <li key={sec.number}>
                  <div className="px-3 pt-2 pb-1 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                    {sec.number}　<MathText as="span" text={sec.title} />
                  </div>
                  <ul>
                    {sec.subsections.map((sub) => (
                      <li key={sub.number}>
                        <button
                          onClick={() => {
                            onSelect(id, `sub-${sub.number.replace(/\./g, '-')}`);
                            onClose?.();
                          }}
                          className="flex w-full items-start gap-2 rounded-md px-3 py-1 text-left text-[13px] leading-snug text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                        >
                          <span className="w-12 shrink-0 font-mono text-[11px] text-slate-400">{sub.number}</span>
                          <MathText as="span" text={sub.title} className="flex-1" />
                          <StatusBadge status={sub.status} small />
                        </button>
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
            </ul>
          </div>
        );
      })}
      <div className="border-t border-slate-100 px-3 py-3">
        <button
          onClick={() => {
            onSelect('latex');
            onClose?.();
          }}
          className={cn(
            'w-full rounded-lg px-3 py-2 text-left text-sm font-medium transition',
            view === 'latex' ? 'bg-slate-900 text-white' : 'text-slate-700 hover:bg-slate-100',
          )}
        >
          LaTeX 源码与下载
        </button>
      </div>
    </nav>
  );
}
