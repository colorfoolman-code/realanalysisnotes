import type { Block, Subsection } from '../content/types';
import { BLOCK_NAMES } from '../content/types';
import { MathText } from './MathText';
import { StatusBadge } from './Sidebar';
import { cn } from '../utils/cn';

const KIND_STYLE: Record<Block['kind'], { bar: string; chip: string }> = {
  anchor: { bar: 'border-slate-300', chip: 'bg-slate-100 text-slate-600' },
  recall: { bar: 'border-teal-400', chip: 'bg-teal-50 text-teal-700' },
  pitfall: { bar: 'border-amber-400', chip: 'bg-amber-50 text-amber-800' },
  deps: { bar: 'border-cyan-400', chip: 'bg-cyan-50 text-cyan-700' },
  motivation: { bar: 'border-rose-400', chip: 'bg-rose-50 text-rose-700' },
  build: { bar: 'border-sky-400', chip: 'bg-sky-50 text-sky-700' },
  example: { bar: 'border-emerald-400', chip: 'bg-emerald-50 text-emerald-700' },
  counter: { bar: 'border-orange-400', chip: 'bg-orange-50 text-orange-700' },
  proof: { bar: 'border-indigo-400', chip: 'bg-indigo-50 text-indigo-700' },
  link: { bar: 'border-fuchsia-400', chip: 'bg-fuchsia-50 text-fuchsia-700' },
  scope: { bar: 'border-slate-300', chip: 'bg-slate-100 text-slate-600' },
  para: { bar: 'border-slate-300', chip: 'bg-slate-100 text-slate-600' },
};

function chipText(b: Block): string {
  if (b.kind === 'example') return `例 ${b.label ?? ''}`.trim();
  if (b.kind === 'counter') return `反例 ${b.label ?? ''}`.trim();
  if (b.kind === 'build') return b.label ? `${BLOCK_NAMES.build} ${b.label}` : BLOCK_NAMES.build;
  return BLOCK_NAMES[b.kind];
}

function BlockView({ block }: { block: Block }) {
  const st = KIND_STYLE[block.kind];
  return (
    <div className={cn('border-l-4 pl-4', st.bar)}>
      <div className="mb-1 flex flex-wrap items-center gap-2">
        <span className={cn('rounded px-1.5 py-0.5 text-[11px] font-semibold tracking-wide', st.chip)}>{chipText(block)}</span>
        {block.title && (
          <MathText text={block.title} className="text-sm font-semibold text-slate-800" />
        )}
      </div>
      <div className="space-y-2">
        {block.paras.map((p, i) => (
          <MathText key={i} text={p} className="text-[15px] leading-7 text-slate-700" />
        ))}
      </div>
    </div>
  );
}

export function SubsectionCard({ sub }: { sub: Subsection }) {
  const id = `sub-${sub.number.replace(/\./g, '-')}`;
  return (
    <article id={id} className="scroll-mt-24 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
      <header className="mb-6 border-b border-slate-100 pb-4">
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-mono text-sm text-slate-400">{sub.number}</span>
          <StatusBadge status={sub.status} />
          <span className="text-xs text-slate-400">约 {sub.pages} 页</span>
        </div>
        <MathText text={sub.title} className="mt-2 text-xl font-semibold tracking-tight text-slate-900 sm:text-2xl" />
        <div className="mt-2 font-mono text-[11px] text-slate-400">
          {sub.status === '保留并慢化' ? `原 label：${sub.origLabel}` : `建议 label：${sub.label}`}
          {sub.status === '前移' && `　（旧 label ${sub.origLabel} 以 \\subsectionalias 保留）`}
        </div>
      </header>
      <div className="space-y-5">
        {sub.blocks.map((b, i) => (
          <BlockView key={i} block={b} />
        ))}
      </div>
    </article>
  );
}
