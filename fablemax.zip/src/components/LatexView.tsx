import { useMemo, useState } from 'react';
import { chapters, preface, revisionNotes } from '../content';
import { buildTexFiles } from '../latex/generate';
import { cn } from '../utils/cn';

function download(name: string, content: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

export function LatexView() {
  const files = useMemo(() => buildTexFiles(preface, revisionNotes, chapters), []);
  const [active, setActive] = useState(0);
  const [copied, setCopied] = useState(false);
  const file = files[active];

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(file.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* ignore */
    }
  };

  const downloadAll = () => {
    files.forEach((f, i) => setTimeout(() => download(f.name, f.content), i * 150));
  };

  return (
    <div className="mx-auto max-w-5xl space-y-6 px-4 py-10 sm:px-8">
      <header>
        <div className="text-xs font-semibold uppercase tracking-widest text-slate-400">LaTeX</div>
        <h1 className="mt-2 text-3xl font-bold tracking-tight text-slate-900">LaTeX 源码与下载</h1>
        <p className="mt-3 text-[15px] leading-7 text-slate-600">
          下列文件由本页数据自动生成，与阅读视图内容一致。将全部文件放入同一目录，用 XeLaTeX 编译
          <code className="mx-1 rounded bg-slate-100 px-1.5 py-0.5 text-sm">00-master-plan.tex</code>
          即可；若并入现有主文档，只需 <code className="rounded bg-slate-100 px-1.5 py-0.5 text-sm">\input</code> 三个章文件与总纲文件，并删除
          <code className="mx-1 rounded bg-slate-100 px-1.5 py-0.5 text-sm">\insertedsubsection</code> 的 providecommand 定义。
        </p>
      </header>

      <div className="flex flex-wrap items-center gap-2">
        {files.map((f, i) => (
          <button
            key={f.name}
            onClick={() => setActive(i)}
            className={cn(
              'rounded-lg border px-3 py-1.5 font-mono text-xs transition',
              i === active ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100',
            )}
          >
            {f.name}
          </button>
        ))}
        <div className="ml-auto flex gap-2">
          <button onClick={copy} className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100">
            {copied ? '已复制' : '复制当前文件'}
          </button>
          <button onClick={() => download(file.name, file.content)} className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100">
            下载当前文件
          </button>
          <button onClick={downloadAll} className="rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-700">
            下载全部 {files.length} 个文件
          </button>
        </div>
      </div>

      <pre className="max-h-[70vh] overflow-auto rounded-2xl border border-slate-200 bg-slate-950 p-5 text-[12.5px] leading-6 text-slate-100">
        <code>{file.content}</code>
      </pre>
      <p className="text-xs text-slate-400">
        {file.name}：{file.content.split('\n').length} 行，{file.content.length.toLocaleString()} 字符。
      </p>
    </div>
  );
}
