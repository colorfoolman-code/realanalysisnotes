import { revisionNotes } from '../content';
import { MathText } from './MathText';

export function NotesView() {
  return (
    <div className="mx-auto max-w-4xl space-y-8 px-4 py-10 sm:px-8">
      <header className="space-y-3">
        <div className="text-xs font-semibold uppercase tracking-widest text-slate-400">修订说明</div>
        <h1 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">{revisionNotes.title}</h1>
        <p className="text-lg text-slate-600">{revisionNotes.subtitle}</p>
      </header>
      {revisionNotes.sections.map((s) => (
        <section key={s.title} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
          <h2 className="mb-3 text-lg font-semibold text-slate-900">{s.title}</h2>
          <div className="space-y-3">
            {s.paras.map((p, i) => (
              <MathText key={i} text={p} className="text-[15px] leading-7 text-slate-700" />
            ))}
          </div>
          {s.bullets && s.bullets.length > 0 && (
            <ul className="mt-3 list-disc space-y-2 pl-5">
              {s.bullets.map((b, i) => (
                <li key={i}>
                  <MathText text={b} className="text-[15px] leading-7 text-slate-700" />
                </li>
              ))}
            </ul>
          )}
        </section>
      ))}
    </div>
  );
}
