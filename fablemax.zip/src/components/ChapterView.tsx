import type { Chapter } from '../content/types';
import { countSubsections } from '../content';
import { MathText } from './MathText';
import { SubsectionCard } from './SubsectionCard';

export function ChapterView({ chapter }: { chapter: Chapter }) {
  const c = countSubsections(chapter);
  return (
    <div className="mx-auto max-w-4xl space-y-10 px-4 py-10 sm:px-8">
      <header>
        <div className="text-xs font-semibold uppercase tracking-widest text-slate-400">Chapter {chapter.number}</div>
        <h1 className="mt-2 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">{chapter.title}</h1>
        <div className="mt-4 flex flex-wrap gap-2 text-xs">
          <Stat label="三级节" value={`${c.total}`} />
          <Stat label="保留并慢化／前移" value={`${c.kept}`} />
          <Stat label="新增" value={`${c.added}`} />
          <Stat label="新增主题" value={`${c.topics}`} />
          <Stat label="参考篇幅" value={`约 ${c.pages} 页`} />
        </div>
      </header>

      <section className="rounded-2xl border border-slate-200 bg-gradient-to-br from-slate-50 to-white p-6 sm:p-8">
        <h2 className="mb-4 text-lg font-semibold text-slate-900">章主线</h2>
        <div className="space-y-3">
          {chapter.thread.map((p, i) => (
            <MathText key={i} text={p} className="text-[15px] leading-7 text-slate-700" />
          ))}
        </div>
      </section>

      {chapter.sections.map((sec) => (
        <section key={sec.number} className="space-y-6">
          <div className="sticky top-14 z-10 -mx-4 border-y border-slate-200 bg-white/90 px-4 py-3 backdrop-blur sm:-mx-8 sm:px-8">
            <div className="flex flex-wrap items-baseline gap-3">
              <span className="font-mono text-sm text-slate-400">{sec.number}</span>
              <MathText text={sec.title} className="text-lg font-semibold text-slate-900" />
              {sec.isNew && (
                <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-800">新增二级节</span>
              )}
            </div>
          </div>
          <div className="space-y-3 px-1">
            {sec.lead.map((p, i) => (
              <MathText key={i} text={p} className="text-[15px] leading-7 text-slate-600" />
            ))}
          </div>
          {sec.subsections.map((sub) => (
            <SubsectionCard key={sub.number} sub={sub} />
          ))}
        </section>
      ))}

      <section className="rounded-2xl border border-fuchsia-200 bg-fuchsia-50/40 p-6 sm:p-8">
        <h2 className="mb-4 text-lg font-semibold text-slate-900">章末衔接</h2>
        <div className="space-y-3">
          {chapter.closing.map((p, i) => (
            <MathText key={i} text={p} className="text-[15px] leading-7 text-slate-700" />
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <span className="rounded-full border border-slate-200 bg-white px-3 py-1 text-slate-600">
      <span className="text-slate-400">{label}　</span>
      <span className="font-semibold text-slate-800">{value}</span>
    </span>
  );
}
