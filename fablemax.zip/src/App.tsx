import { useCallback, useEffect, useState } from 'react';
import { chapters } from './content';
import { Sidebar } from './components/Sidebar';
import { PrefaceView } from './components/PrefaceView';
import { ChapterView } from './components/ChapterView';
import { LatexView } from './components/LatexView';
import { NotesView } from './components/NotesView';

export default function App() {
  const [view, setView] = useState<string>('preface');
  const [menuOpen, setMenuOpen] = useState(false);
  const [pendingAnchor, setPendingAnchor] = useState<string | null>(null);

  const select = useCallback((v: string, anchor?: string) => {
    setView(v);
    setPendingAnchor(anchor ?? null);
    if (!anchor) window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    if (!pendingAnchor) return;
    const t = setTimeout(() => {
      const el = document.getElementById(pendingAnchor);
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setPendingAnchor(null);
    }, 50);
    return () => clearTimeout(t);
  }, [pendingAnchor, view]);

  const chapter = chapters.find((c) => `ch${c.number}` === view);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-slate-200 bg-white/90 px-4 backdrop-blur sm:px-6">
        <button
          onClick={() => setMenuOpen((o) => !o)}
          className="rounded-md border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-100 lg:hidden"
          aria-label="切换目录"
        >
          <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
            <path d="M4 7h16M4 12h16M4 17h16" />
          </svg>
        </button>
        <div className="flex min-w-0 items-baseline gap-3">
          <span className="truncate text-sm font-semibold text-slate-900">实分析讲义补充计划 · 第二版 · 第二次修订</span>
          <span className="hidden text-xs text-slate-400 sm:inline">以“有限观测”为主线的三章慢化方案</span>
        </div>
        <div className="ml-auto flex gap-1 text-xs">
          <TopTab active={view === 'preface'} onClick={() => select('preface')}>
            总纲
          </TopTab>
          <TopTab active={view === 'notes'} onClick={() => select('notes')}>
            修订说明
          </TopTab>
          {chapters.map((c) => (
            <TopTab key={c.number} active={view === `ch${c.number}`} onClick={() => select(`ch${c.number}`)}>
              第{['一', '二', '三'][c.number - 1]}章
            </TopTab>
          ))}
          <TopTab active={view === 'latex'} onClick={() => select('latex')}>
            LaTeX
          </TopTab>
        </div>
      </header>

      <div className="flex">
        <aside className="sticky top-14 hidden h-[calc(100vh-3.5rem)] w-80 shrink-0 border-r border-slate-200 lg:block">
          <Sidebar view={view} onSelect={select} />
        </aside>

        {menuOpen && (
          <div className="fixed inset-0 z-40 lg:hidden">
            <div className="absolute inset-0 bg-slate-900/40" onClick={() => setMenuOpen(false)} />
            <div className="absolute inset-y-0 left-0 w-80 max-w-[85vw] border-r border-slate-200 bg-white shadow-xl">
              <Sidebar view={view} onSelect={select} onClose={() => setMenuOpen(false)} />
            </div>
          </div>
        )}

        <main className="min-w-0 flex-1">
          {view === 'preface' && <PrefaceView onOpenChapter={(id) => select(id)} />}
          {view === 'notes' && <NotesView />}
          {chapter && <ChapterView key={chapter.number} chapter={chapter} />}
          {view === 'latex' && <LatexView />}
          <footer className="px-4 pb-10 pt-4 text-center text-xs text-slate-400">
            阅读视图与 LaTeX 源码由同一份数据生成；原有三十六个三级节全部保留，不含路线图、对比表与习题。
          </footer>
        </main>
      </div>
    </div>
  );
}

function TopTab({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={
        'rounded-md px-2.5 py-1 font-medium transition ' + (active ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100')
      }
    >
      {children}
    </button>
  );
}
