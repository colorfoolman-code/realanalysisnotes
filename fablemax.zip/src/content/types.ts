export type BlockKind =
  | 'anchor' // 位置与状态
  | 'recall' // 先修回顾：本节实际使用的 Analysis I/II、拓扑、线性代数事实
  | 'motivation' // 问题引导的动机
  | 'build' // 要建立的对象（定义/命题/定理）
  | 'example' // 例
  | 'counter' // 反例与边界
  | 'proof' // 证明的讲法（慢化）
  | 'pitfall' // 初学者易错点
  | 'link' // 与主线的联系
  | 'deps' // 依赖清单：只允许列出编号更小的节与先修课程
  | 'scope' // 篇幅与边界
  | 'para'; // 一般说明

export interface Block {
  kind: BlockKind;
  label?: string; // 例如 E1 / C2 / D1 / P1 / T1
  title?: string;
  paras: string[];
}

export type SubStatus = '新增' | '新增主题' | '保留并慢化' | '前移';

export interface Subsection {
  number: string;
  title: string;
  status: SubStatus;
  label: string; // 建议正文 label
  origLabel?: string; // 原稿 label（保留节）
  pages: number;
  blocks: Block[];
}

export interface Section {
  number: string;
  title: string;
  isNew?: boolean;
  lead: string[];
  subsections: Subsection[];
}

export interface Chapter {
  number: number;
  title: string;
  short: string;
  file: string;
  thread: string[];
  sections: Section[];
  closing: string[];
}

export interface Preface {
  title: string;
  subtitle: string;
  paras: string[];
  prerequisites: { title: string; items: string[] }[];
  threads: { title: string; paras: string[] }[];
  conventions: string[];
}

export interface NotesSection {
  title: string;
  paras: string[];
  bullets?: string[];
}

export interface Notes {
  title: string;
  subtitle: string;
  sections: NotesSection[];
}

export const BLOCK_NAMES: Record<BlockKind, string> = {
  anchor: '位置与状态',
  recall: '先修回顾',
  motivation: '问题引导的动机',
  build: '要建立的对象',
  example: '例',
  counter: '反例与边界',
  proof: '证明的讲法',
  pitfall: '初学者易错点',
  link: '与主线的联系',
  deps: '依赖清单（只向后）',
  scope: '篇幅与边界',
  para: '说明',
};
