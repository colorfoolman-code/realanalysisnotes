import type { Section } from './types';

const r = String.raw;

export const ch3SectionsA: Section[] = [
  {
    number: '3.0',
    title: '积分语言的入场准备',
    isNew: true,
    lead: [
      '本二级节只有一个三级节。它把可测函数的阈值观测、可测函数的运算封闭性、简单函数的值层表示、表示无关与 dyadic 逼近拆成可算实验，让 3.1.1 能专心解释上确界构造。Rademacher 函数在此作为简单函数首次出场。',
    ],
    subsections: [
      {
        number: '3.0.1',
        title: '可测函数与简单函数计算实验室',
        status: '新增',
        label: 'subsec:3-0-1-measurable-simple-lab',
        pages: 9,
        blocks: [
          { kind: 'anchor', paras: ['新增文件 sec-03-00.tex，置于章导言之后、原 3.1.1 之前。进入原 sec:03-01 时计数器重置，原 3.1.1 的显示号不变。'] },
          { kind: 'recall', paras: ['第二章：2.0.2 P1（射线生成 Borel）、2.1.3（零测集、a.e.、E5）、2.3.1（可测映射、P1、E5）。Analysis I：$\\mathbb Q$ 稠密、$\\sup$ 与 $\\limsup$ 的刻画、取整函数。基础拓扑：扩展实数 $[-\\infty,\\infty]$ 的序（1.2.3）。'] },
          {
            kind: 'motivation',
            paras: [
              '一张只有五种灰度的数字图像，每个像素区域带非均匀权重，求平均灰度。把同一灰度的区域拆成多块再合并，结果不应依赖绘图者如何切块——这个要求在证明中对应“表示无关”，是定义积分之前必须清偿的义务。第二个问题：可测函数是什么？2.0.2 说射线生成 Borel 集，于是“对每个阈值 $a$，$\\{f>a\\}$ 可测”就足以让所有 Borel 集的逆像可测（2.3.1 P1）。可测函数就是每个阈值观测都可测的函数。第三个问题：两个可测函数的和为什么可测？$\\{f+g>a\\}$ 不是 $\\{f>b\\}$ 与 $\\{g>c\\}$ 的简单组合——但它是可数个这样的组合之并，有理数在此承担了“可数观测”的角色。',
            ],
          },
          {
            kind: 'build',
            label: 'D1–D3',
            title: '水平集测试、规范值层、dyadic 截断',
            paras: [r`D1：$f:X\to[-\infty,\infty]$ 可测，若对每个 $a\in\mathbb R$，$\{f>a\}\in\mathcal A$；四种阈值测试（$>,\ge,<,\le$）等价（$\{f\ge a\}=\bigcap_n\{f>a-1/n\}$ 与补集），且可只取 $a\in\mathbb Q$。D2：简单函数为有限值可测函数，$s=\sum_ja_j\mathbf 1_{\{s=a_j\}}$ 为规范表示（$a_j$ 两两不同，值层两两不交）。D3：对 $f\ge0$，$s_n=2^{-n}\lfloor2^n(f\wedge n)\rfloor$；验证 $0\le s_n\le f$、可测、值域有限（至多 $n2^n+1$ 个值）、$s_n\uparrow f$。`] },
          {
            kind: 'build',
            label: 'P1–P3',
            title: '共同细分、运算封闭、逼近单调',
            paras: [r`P1：两种表示 $\sum a_i\mathbf 1_{A_i}=\sum b_j\mathbf 1_{B_j}$ 的全部集合生成的有限布尔代数的原子上，两种系数和都等于同一个 $s$ 值；由此“简单函数的积分”（3.1.1）表示无关。P2：可测函数的和、积、$\max$、$\min$、$|f|$、$f^\pm$ 可测，与 Borel 函数的复合可测；关键一步 $\{f+g>a\}=\bigcup_{q\in\mathbb Q}\{f>q\}\cap\{g>a-q\}$（若 $f(x)+g(x)>a$，取有理数 $q$ 满足 $a-g(x)<q<f(x)$）；积由 $fg=\frac14((f+g)^2-(f-g)^2)$ 与 $x\mapsto x^2$ 连续。扩展实值时先约定 $0\cdot\infty=0$ 并排除 $\infty-\infty$。P3：dyadic 近似逐点单调（$2^{-n}\lfloor2^nt\rfloor\le2^{-n-1}\lfloor2^{n+1}t\rfloor$ 与截断高度递增），$f(x)=\infty$ 时 $s_n(x)=n\to\infty$。`] },
          {
            kind: 'build',
            label: 'P4',
            title: '极限运算封闭',
            paras: [r`可数族 $\{f_n\}$ 的 $\sup,\inf,\limsup,\liminf$ 可测：$\{\sup f_n>a\}=\bigcup\{f_n>a\}$，$\liminf f_n=\sup_N\inf_{n\ge N}f_n$。收敛集 $\{x:\lim f_n(x)\text{ 存在于 }\mathbb R\}=\{\limsup f_n=\liminf f_n\}\cap\{|\limsup f_n|<\infty\}$ 可测（2.0.2 E4 的写法在此对一般可测函数成立）；极限在收敛集上可测。1.0.1 的量词训练在此第三次回收。`] },
          {
            kind: 'example',
            label: 'E1–E4',
            title: '四个计算模型',
            paras: [r`五点空间质量 $(1,2,1,3,3)/10$ 上三个简单函数的值层与加权和，其中一个给两种分块表示并用 P1 的原子比较；$[0,1]$ 上三层阶梯函数，修改端点后点态函数、a.e. 等价类与有限和分别是否改变；$f(n)=n$ 在带几何权重 $2^{-n}$ 的 $\mathbb N$ 上可测但不简单，前三个 dyadic 近似的加权和为 $\sum_{n\le N}n2^{-n}$ 型部分和；$x^{-1/2}$ 于 $(0,1]$ 的前三个 dyadic 近似的值层（$\{s_1=1/2\}=\{1/2\le x^{-1/2}<1\}=\varnothing$ 等，学生逐层画出）。`] },
          {
            kind: 'example',
            label: 'E5',
            title: 'a.e. 定义的函数与 Borel 代表',
            paras: ['在完备测度空间上，与可测函数 a.e. 相等的函数可测；只在零测集外定义的函数可以任意补值后可测。由 2.1.3 E5，每个 Lebesgue 可测函数与一个 Borel 可测函数 a.e. 相等（对 dyadic 近似的每个值层取 $F_\\sigma$ 内逼近，再取极限）。3.1.4 Lusin 的完成测度版本需要这条。'],
          },
          {
            kind: 'example',
            label: 'E6',
            title: '复合的可测性',
            paras: ['Borel 函数复合可测函数可测（2.3.1 P2），特别地连续函数与单调函数复合可测函数可测；Lebesgue 可测函数复合连续函数未必 Lebesgue 可测（只作警告，见证需 Cantor 函数改造的同胚把零测集映成正测度集，然后取 2.1.4 P3 的不可测子集）。这是 3.2.2 中要求 Borel 可测被积函数、或先取 Borel 代表的原因。'],
          },
          {
            kind: 'example',
            label: 'E7',
            title: 'Rademacher 函数',
            paras: [r`$r_k(x)=1-2d_k(x)$，其中 $d_k$ 是二进制第 $k$ 位（2.3.1 E5）。它取值 $\pm1$，值层是 $2^{k-1}$ 个长 $2^{-k}$ 的二进区间之并，因而是简单函数。有限加权和意义下 $\sum_{\text{值层}}(\pm1)\cdot m(\text{值层})=0$，且 $r_jr_k$（$j<k$）在每个第 $k$ 层二进区间上取 $\pm1$ 各一半，故其加权和为 $\delta_{jk}$。贯穿问题 A 在第三章的第一个对象；正式的“积分”记号在 3.1.1 之后使用。`] },
          {
            kind: 'example',
            label: 'E8',
            title: '可测但处处不连续、与连续函数 a.e. 相等',
            paras: ['Dirichlet 函数可测（$\\mathbb Q$ 是 Borel 集）、处处不连续、a.e. 等于常数 $0$。可测性对“坏点”完全不敏感，这与 Riemann 可积性形成对照（2.1.1）。'],
          },
          {
            kind: 'counter',
            label: 'C1–C3',
            title: '三个边界',
            paras: [r`$\mathbf 1_A-2\mathbf 1_B$ 不能送进非负积分构造（3.1.3 才处理符号）；$\mathbf 1_A+\mathbf 1_B$ 的系数逐项相配在 $A\cap B$ 上失败（规范表示的值层是 $A\setminus B$、$B\setminus A$、$A\cap B$）；$1/x$ 于 $(0,1)$ 可测但积分将为无穷——可测提供定义资格，不保证有限。`] },
          {
            kind: 'counter',
            label: 'C4',
            title: '“可测”的对象是函数，不是数',
            paras: ['学生常写“$f(x)$ 可测”。可测性是函数（及其 $\\sigma$-代数）的性质；一个数没有可测性。类型签名（1.0.1 D1）在此再用一次。'],
          },
          { kind: 'pitfall', paras: ['（一）“可测”与“可积”混用（C3）。（二）以为简单函数必须是阶梯函数（简单函数的值层可以是任何可测集，如 $\\mathbf 1_{\\mathbb Q}$）。（三）P2 中把 $\\{f+g>a\\}$ 写成 $\\{f>a/2\\}\\cup\\{g>a/2\\}$。（四）忘记 dyadic 近似中的截断 $f\\wedge n$，导致值域无限。'] },
          { kind: 'link', paras: ['3.1.1 依赖 P1 与 D3；3.1.2 依赖 P4；3.1.4 Lusin 的简单函数步骤与 E5；3.2.4 的 Rademacher 函数；3.4.1 的 Bochner 简单函数只回引本节有限模型。'] },
          { kind: 'deps', paras: ['2.0.2、2.1.3、2.1.4（E6 警告）、2.3.1；1.0.1、1.2.3；先修课程。'] },
          { kind: 'scope', paras: ['约 9 页。不提前证明 MCT、Fatou 或 DCT。'] },
        ],
      },
    ],
  },
  {
    number: '3.1',
    title: '标量积分：构造、极限与收敛模式',
    lead: [
      '本二级节的主线问题是“极限的平均何时等于平均的极限”。3.1.1 建立非负积分与 Markov 不等式，3.1.2 给三大极限定理，新增的 3.1.2A 用具体函数列训练假设选择，3.1.3 处理有符号与复值并证明阶梯函数稠密与 Riemann–Lebesgue 引理，新增的 3.1.4 把 Dini 与紧内正则升级为 Egorov 与 Lusin（Littlewood 第二、三原理），前移的 3.1.5 完成收敛模式的图廊，新增主题 3.1.6 用有界收敛定理回收第二章开出的 Riemann 账单。',
    ],
    subsections: [
      {
        number: '3.1.1',
        title: '从简单函数到正积分',
        status: '保留并慢化',
        label: 'subsec:3-1-1',
        origLabel: 'subsec:3-1-1',
        pages: 9,
        blocks: [
          { kind: 'anchor', paras: ['全部定义、命题、证明与例保留；与 3.0.1 重复的基本操作只作回引。新增 Markov 不等式与“积分对定义域可数可加”的命名。'] },
          { kind: 'recall', paras: ['3.0.1（P1、D3、P3）；2.1.2（测度）、2.1.3A（P1）；1.1.1 E3（无序求和）；Analysis I：上确界、非负级数。'] },
          {
            kind: 'motivation',
            paras: ['为什么用“所有下方简单函数积分的上确界”而不是“某个逼近列的极限”定义？因为上确界不依赖逼近列的选择，这是表示无关的升级版；单调收敛定理（3.1.2）随后证明任何单调逼近列都给同一个值。计数测度下积分就是 1.1.1 E3 的无序求和：非负级数的无序和等于有限子和的上确界。'],
          },
          {
            kind: 'build',
            label: 'D1–D2, P1–P4',
            title: '简单积分、非负积分与基本性质',
            paras: [r`D1：$\int s\,d\mu=\sum a_j\mu(\{s=a_j\})$（约定 $0\cdot\infty=0$），由 3.0.1 P1 表示无关；线性、单调。D2：$\int f\,d\mu=\sup\{\int s:0\le s\le f\text{ 简单}\}$，允许 $+\infty$。P1 单调性与齐次性；P2 简单函数的积分对定义域可数可加（$E\mapsto\int_Es$ 是测度，由 $\mu$ 的可数可加）；P3 Markov 不等式 $\mu(\{f\ge t\})\le t^{-1}\int f$（对简单函数 $t\mathbf 1_{\{f\ge t\}}\le f$ 取上确界）；P4 $\int f=0$ 当且仅当 $f=0$ a.e.（Markov 加可数并）。有限可加性 $\int(f+g)=\int f+\int g$ 留到 3.1.2 用 MCT 证明，此处只证 $\ge$ 方向平凡的一半并标明欠账。`] },
          {
            kind: 'example',
            label: 'E1–E3',
            title: '三类模型',
            paras: [r`计数测度下的非负级数（$\int f\,d\#=\sum f(n)$）；Dirac 测度下积分等于函数值；$x^{-\alpha}$ 在 $(0,1)$ 与 $(1,\infty)$ 上的可积阈值 $\alpha<1$ 与 $\alpha>1$（用简单函数 $\sum_k2^{k\alpha}\mathbf 1_{(2^{-k-1},2^{-k}]}$ 型下界与上界夹住，此处不借助 Riemann 积分）。`] },
          {
            kind: 'example',
            label: 'E4',
            title: '由密度定义的测度',
            paras: [r`$f\ge0$ 可测时 $\nu(E)=\int_Ef\,d\mu$ 单调、对有限不交并可加（P2 对简单函数，一般 $f$ 的有限可加留 3.1.2）；可数可加性需要 3.1.2 的 MCT，此处标记为“3.1.2 后回收”。这是 3.3.0 密度的第一次出场，也是 2.2.2 E1、2.2.3 E3 中“Riemann 密度”的一般化。`] },
          {
            kind: 'example',
            label: 'E5',
            title: 'Markov 不等式的两个立即用途',
            paras: [r`$\int f<\infty$ 推出 $f<\infty$ a.e.（$\mu(f=\infty)\le\mu(f\ge t)\le t^{-1}\int f\to0$）；$\int f=0$ 推出 $f=0$ a.e.（P4）。1.3.3 E5 的 Bernstein 估计是同一个不等式在二项分布上的实例；3.2.4 把它推广为 Chebyshev 不等式。`] },
          {
            kind: 'example',
            label: 'E6',
            title: '积分不依赖零测集上的值',
            paras: ['若 $f=g$ a.e. 则 $\\int f=\\int g$（对每个 $s\\le f$，修改零测集后 $\\le g$ 且积分不变）。这是“a.e. 等价类”的第一次实用；3.3.2 把 $L^p$ 定义为等价类的空间。'],
          },
          {
            kind: 'counter',
            label: 'C1–C2',
            title: '两个边界',
            paras: ['积分为零只推出 a.e. 为零，不推出处处为零（$\\mathbf 1_{\\mathbb Q}$）；a.e. 有限不保证可积（$1/x$ 于 $(0,1)$）。'],
          },
          {
            kind: 'counter',
            label: 'C3',
            title: '上确界定义中不能只用阶梯函数',
            paras: ['在 $[0,1]$ 上若只允许阶梯函数（区间上常值）作下方逼近，则 $\\mathbf 1_{[0,1]\\setminus\\mathbb Q}$ 的“积分”为 $0$（任何区间含有理数），而它 a.e. 等于 $1$。允许任意可测集为值层正是 Lebesgue 与 Riemann 的分界。'],
          },
          { kind: 'pitfall', paras: ['（一）以为非负积分“可能未定义”；它总有定义，只是可能为 $+\\infty$。（二）在有限可加性未证时就把它当作已知（本节明确标欠账）。（三）Markov 不等式中把 $\\ge t$ 写成 $>t$ 无妨，但把 $t^{-1}$ 写成 $t$ 会得到错误方向。'] },
          { kind: 'link', paras: ['3.1.2（MCT 回填有限可加与 E4）、3.1.2A、3.1.5（E3 用 Markov）、3.2.4（Chebyshev）、3.3.0。'] },
          { kind: 'deps', paras: ['3.0.1；2.1.2、2.1.3A；1.1.1（E3）。'] },
          { kind: 'scope', paras: ['约 9 页。不使用 DCT、Tonelli 或 $L^p$。'] },
        ],
      },
      {
        number: '3.1.2',
        title: '单调收敛、Fatou 与控制收敛',
        status: '保留并慢化',
        label: 'subsec:3-1-2',
        origLabel: 'subsec:3-1-2',
        pages: 12,
        blocks: [
          { kind: 'anchor', paras: ['MCT、Fatou、DCT 及原有网版本边界全部保留。序列版本为核心，网版本与选择论成本为延伸评注。'] },
          { kind: 'recall', paras: ['3.0.1（P3、P4）、3.1.1；2.1.3A（P1、P5）；1.3.1A（E3、E6、Dini）、1.1.1 P0。Analysis I：$(1-x/n)^n\\uparrow e^{-x}$、$\\liminf$。'] },
          {
            kind: 'motivation',
            paras: [
              r`回收 1.3.1A E3：$nx(1-x^2)^n\to0$ 逐点，积分趋于 $1/2$；而 $x^n\to0$ a.e. 且积分趋于 $0$。区别在哪里？前者的上包络 $\sup_nf_n$ 在 $0$ 附近像 $1/x$（在 $x\approx1/\sqrt n$ 处 $f_n\approx\sqrt n$），不可积；后者由常数 $1$ 支配。Analysis II 用“一致收敛”保证交换（1.3.1A E6），代价太高：$x^n$ 在 $[0,1]$ 上不一致收敛却可以交换。MCT 是 2.1.3A 从下连续性的函数版（对指标函数就是它），Fatou 是集合版 Fatou（2.1.3A P5）的函数版，DCT 把“一致”换成“被一个可积函数支配”。`,
            ],
          },
          {
            kind: 'build',
            label: 'T1–T3',
            title: '三大定理',
            paras: [r`T1（MCT）：$0\le f_n\uparrow f$ a.e. 则 $\int f_n\uparrow\int f$。T2（Fatou）：$f_n\ge0$ 则 $\int\liminf f_n\le\liminf\int f_n$。T3（DCT）：$f_n\to f$ a.e.，$|f_n|\le g$ a.e.，$g$ 可积，则 $f$ 可积、$\int f_n\to\int f$ 且 $\int|f_n-f|\to0$。推论：非负积分有限可加（对 $f,g$ 取 dyadic 近似之和用 MCT）；由密度定义的测度可数可加（3.1.1 E4 回填）。`] },
          {
            kind: 'example',
            label: 'E1–E2',
            title: 'MCT 的两个直接后果',
            paras: [r`由密度定义的测度可数可加；非负级数可逐项积分 $\int\sum f_n=\sum\int f_n$。对 $\mathbb N$ 上计数测度这就是非负二重级数可交换次序（1.1.1 E3 的无序和）。`] },
          {
            kind: 'example',
            label: 'E3',
            title: 'Gamma 函数的极限表示',
            paras: [r`$\lim_n\int_0^n(1-x/n)^nx^{s-1}\,dx=\Gamma(s)$（$s>0$）：由 $(1-x/n)^n\mathbf 1_{[0,n]}\uparrow e^{-x}$（1.3.1A E2 的单调性）直接用 MCT，或由支配 $e^{-x}x^{s-1}$ 用 DCT。同一个例两条路线，学生比较哪条假设更弱。`] },
          {
            kind: 'example',
            label: 'E4',
            title: '递减列需要有限首项',
            paras: [r`$f_n=\mathbf 1_{(n,\infty)}$ 递减到零而积分恒为无穷，正是 2.1.3A E3 的函数版；$\int f_1<\infty$ 时对 $f_1-f_n\uparrow f_1-f$ 用 MCT 可得递减版。`] },
          {
            kind: 'example',
            label: 'E5',
            title: '绝对可和级数 a.e. 收敛',
            paras: [r`若 $\sum\int|f_n|<\infty$，则 $\sum|f_n|<\infty$ a.e.（MCT 加 3.1.1 E5），故 $\sum f_n$ a.e. 收敛，且由 DCT（支配 $\sum|f_n|$）可逐项积分。3.3.2 的 Riesz–Fischer 证明就是这条对 $f_{n_{k+1}}-f_{n_k}$ 的应用。`] },
          {
            kind: 'example',
            label: 'E6',
            title: 'Dini 与 MCT 并排',
            paras: ['1.3.1A P2 说“紧、单调、极限连续”给一致收敛，从而积分交换；MCT 说“非负、单调”就够，不需要紧、不需要连续、不需要一致。学生看到测度论用“可数可加”替换了“紧性”所做的工作。'],
          },
          {
            kind: 'counter',
            label: 'C1–C3',
            title: '每条定理后紧跟一个反例',
            paras: [r`尖峰 $n\mathbf 1_{(0,1/n)}$：Fatou 严格不等（$0<1$），DCT 缺支配（$\sup_nf_n\ge\frac1{2x}$ 于 $(0,1/2)$ 型下界不可积）；逃逸 $\mathbf 1_{[n,n+1]}$：常数 $1$ 在 $\mathbb R$ 上不可积；有符号列 $-n\mathbf 1_{(0,1/n)}$：非负假设不能省（$\int\liminf=0>-1=\liminf\int$）。`] },
          {
            kind: 'proof',
            paras: [r`MCT 拆成两向：$\le$ 由单调性；$\ge$ 固定简单 $s\le f$ 与 $c<1$，集合 $E_n=\{f_n\ge cs\}\uparrow X$，$\int f_n\ge c\int_{E_n}s\to c\int s$（3.1.1 P2 与 2.1.3A P1），令 $c\uparrow1$ 再对 $s$ 取上确界。Fatou 显式构造尾部下确界 $g_N=\inf_{n\ge N}f_n\uparrow\liminf f_n$，$\int g_N\le\inf_{n\ge N}\int f_n$，用 MCT。DCT 对 $g\pm f_n\ge0$ 使用 Fatou 两次，标出使用位置；$\int|f_n-f|\to0$ 对 $2g-|f_n-f|$ 再用一次。`] },
          { kind: 'pitfall', paras: ['（一）DCT 的支配函数必须与 $n$ 无关；“每个 $f_n$ 可积”不是支配。（二）Fatou 是不等式，方向是 $\\int\\liminf\\le\\liminf\\int$；写反的学生把质量“凭空创造”。（三）MCT 需要非负（或共同可积下界）；递减版需要有限首项（E4）。（四）在无限测度空间上用常数作支配（C2）。'] },
          { kind: 'link', paras: ['3.1.2A、3.1.3、3.1.6、3.2.3、3.3.2（E5）。'] },
          { kind: 'deps', paras: ['3.0.1、3.1.1；2.1.3A；1.1.1（P0）、1.3.1A。'] },
          { kind: 'scope', paras: ['约 12 页。'] },
        ],
      },
      {
        number: '3.1.2A',
        title: '极限与积分交换：假设的功能与失败图廊',
        status: '新增',
        label: 'subsec:3-1-2a-limit-integral-exchange-gallery',
        pages: 9,
        blocks: [
          { kind: 'anchor', paras: ['置于原 3.1.2 结束之后、原 3.1.3 之前。不重证原定理。'] },
          { kind: 'recall', paras: ['3.1.1、3.1.2；1.3.1A（E5 幂级数）；Analysis II：反常积分、幂级数的逐项积分（一致收敛版本）。'] },
          {
            kind: 'motivation',
            paras: [
              '学生把所有“极限与积分交换”都写成 DCT，或把 Fatou 的不等式写成等式。本节以八个具体函数列为对象，每个都先问四个问题——符号如何、是否单调、有无与 $n$ 无关的可积支配、尾部能否单独控制——然后用文字写出判断与理由。它训练的是决策，不是第四个定理。第四个工具（积分的绝对连续性）在此证明，因为它是 Vitali（3.1.5）与第四章微分的公共输入。',
            ],
          },
          {
            kind: 'build',
            label: 'T4',
            title: '积分的绝对连续性（小集合控制）',
            paras: [r`$g\ge0$ 可积时，对每个 $\varepsilon$ 存在 $\delta$，使 $\mu(E)<\delta$ 蕴含 $\int_Eg<\varepsilon$。证明用截断：$g\wedge M\uparrow g$，MCT 给 $M$ 使 $\int(g-g\wedge M)<\varepsilon/2$；再取 $\delta=\varepsilon/(2M)$。名字的来源在 3.3.0：由密度定义的测度关于 $\mu$ 绝对连续，且这里给出了 $\varepsilon$–$\delta$ 形式。`] },
          {
            kind: 'example',
            label: 'E1',
            title: '安全截断',
            paras: [r`$f_n=f\wedge n$，$f\ge0$：MCT，无需先知 $f$ 可积。区分“定义积分”与“证明可积”。`] },
          {
            kind: 'example',
            label: 'E2',
            title: '递减修复',
            paras: [r`$\mathbf 1_{(0,1/n)}$ 直接 MCT 方向不对；对 $f_1-f_n\uparrow f_1$ 用 MCT，并指出 $\int f_1<\infty$ 的角色（3.1.2 E4）。`] },
          {
            kind: 'example',
            label: 'E3',
            title: '幂级数逐项积分',
            paras: [r`$\int_0^r\sum a_kx^k\,dx$：非负系数用 MCT（对任何 $r$ 不超过收敛半径，允许和为无穷）；有符号且 $\sum|a_k|r^k<\infty$ 时用 DCT（支配 $\sum|a_k|r^k$）；一致收敛版本（Analysis II）只在 $r$ 严格小于收敛半径时可用。三条许可不同。`] },
          {
            kind: 'example',
            label: 'E4',
            title: '阶梯函数的 Riemann–Lebesgue 计算',
            paras: [r`$\int_a^b\sin(nx)\,dx=(\cos na-\cos nb)/n=O(1/n)$，故对任何阶梯函数 $\varphi$，$\int\varphi(x)\sin(nx)\,dx\to0$。这不是极限定理的应用（$\sin(nx)$ 没有逐点极限），而是显式计算。推广到一般 $f\in L^1$ 需要第二种交换技术——稠密性——在 3.1.3 P4 阶梯函数稠密之后完成（3.1.3 E7）。`] },
          {
            kind: 'example',
            label: 'E5',
            title: '当前没有工具的例',
            paras: [r`$\lim_{t\to0^+}\int_0^\infty e^{-tx}\frac{\sin x}{x}\,dx$：$\sin x/x$ 不可积（3.1.6 E5），DCT 不适用；极限 $\pi/2$ 是反常积分现象，需要分部积分或 Abel 型论证（Analysis II），3.1.6 说明它应放在哪里。`] },
          {
            kind: 'example',
            label: 'E6',
            title: 'Gamma 极限作为 DCT 范例',
            paras: ['即 3.1.2 E3，按“测度空间与对象、a.e. 极限、符号或单调、支配函数及其可积性、结论类型”五行写出；学生模仿此格式写 E1–E3。'],
          },
          {
            kind: 'example',
            label: 'E7',
            title: '两阶段论证的模板',
            paras: [r`要证 $\int f_n\to\int f$ 而没有全局支配：先在大集合 $E$ 上用 DCT 或一致收敛，再用 T4 控制 $\int_{E^c}|f_n|$——后者需要 $E^c$ 的测度小且 $\{f_n\}$ 的尾部一致小。第二个条件就是 3.1.5 的一致可积性；此处只留空槽。`] },
          {
            kind: 'counter',
            label: 'C1–C4',
            title: '四个最小失败',
            paras: [r`尖峰（无可积支配，Fatou 严格不等 $0<1$）；逃逸（常数在无限测度空间不可积，Fatou 也严格不等 $0<1$）；来回移动的块 $\mathbf 1_{[0,1]},\mathbf 1_{[1,2]},\mathbf 1_{[0,1]},\dots$（有界、支撑在有限测度集内、$\liminf f_n=0$ 而 $\int f_n\equiv1$：Fatou 严格不等的最简见证，且说明“$\liminf\int$ 存在”不蕴含“$\int\lim$ 存在”，因为极限根本不存在）；负部失控 $f_n=-n\mathbf 1_{(0,1/n)}$（$\int\liminf f_n=0>-1=\liminf\int f_n$，Fatou 方向反了，需要共同可积下界）。打字机序列（3.1.5）不在此列：它的积分趋于零，Fatou 取等号，它见证的是另一件事——依测度收敛不推 a.e. 收敛。`] },
          { kind: 'pitfall', paras: ['（一）只写“由 DCT”而不写支配函数。（二）把“每个 $f_n$ 有界”当作支配（界可能依赖 $n$）。（三）把稠密性论证（E4）误认为极限定理。（四）以为 T4 的 $\\delta$ 可以与 $g$ 无关。'] },
          { kind: 'link', paras: ['3.1.3（E4 在 P4 后完成）、3.1.5（E7 的空槽）、3.1.6（E5 回收）、3.2.3（参数积分 DCT）、第四章微分（T4）。'] },
          { kind: 'deps', paras: ['3.1.1、3.1.2；1.3.1A；先修课程（幂级数、反常积分）。'] },
          { kind: 'scope', paras: ['约 9 页。不扩展到网版本。'] },
        ],
      },
      {
        number: '3.1.3',
        title: '实值与复值积分',
        status: '保留并慢化',
        label: 'subsec:3-1-3',
        origLabel: 'subsec:3-1-3',
        pages: 11,
        blocks: [
          { kind: 'anchor', paras: ['正负部、绝对可积、实值与复值积分、基本估计全部保留。新增：阶梯函数在 $L^1(\\mathbb R)$ 中稠密、Riemann–Lebesgue 引理、不定积分作为有符号测度。'] },
          { kind: 'recall', paras: ['3.0.1（P2 正负部可测）、3.1.1、3.1.2、3.1.2A（E4、T4）；2.1.3（P2 Littlewood 第一原理）、2.2.3（有符号测度、Jordan）、2.3.1（推前）；1.1.1 E3（无序和与绝对收敛）；Analysis II：$\\int_0^\\infty\\sin x/x$。'] },
          {
            kind: 'motivation',
            paras: [r`$\int_0^\infty\frac{\sin x}{x}\,dx=\pi/2$ 作为反常积分存在，但 $\sin x/x\notin L^1(0,\infty)$，Lebesgue 积分对它说“未定义”，因为正负部都是无穷。这不是缺陷：Lebesgue 积分是绝对收敛型积分，与 1.1.1 E3 的无序求和一致（无序和存在当且仅当绝对收敛）。第二个问题：3.1.2A E4 只对阶梯函数算出了 Riemann–Lebesgue 极限，怎样推广到所有可积函数？需要“阶梯函数在 $L^1$ 中稠密”，而这正是 Littlewood 第一原理（2.1.3 P2）加简单函数逼近的直接后果。`] },
          {
            kind: 'build',
            label: 'D1–D2, P1–P3',
            title: '可积、复值积分、基本估计',
            paras: [r`D1：$f$ 可积若 $\int|f|<\infty$，此时 $\int f=\int f^+-\int f^-$；$L^1(\mu)$ 为可积函数类（a.e. 等价类的语言在 3.3.2 正式化）。D2：复值 $f=u+iv$ 可积若 $|f|$ 可积，$\int f=\int u+i\int v$。P1 线性；P2 $|\int f|\le\int|f|$（复值时取 $\theta$ 使 $e^{-i\theta}\int f\ge0$）；P3 若 $\int_Ef=0$ 对所有 $E$ 则 $f=0$ a.e.`] },
          {
            kind: 'build',
            label: 'P4',
            title: '阶梯函数在 $L^1(\\mathbb R^n)$ 中稠密',
            paras: [r`对 $f\in L^1$ 与 $\varepsilon$：先取简单函数 $s$ 使 $\int|f-s|<\varepsilon/3$（对 $f^\pm$ 用 dyadic 近似与 MCT，3.1.1 E5 保证 $f$ a.e. 有限）；$s$ 的每个非零值层测度有限（否则 $\int|s|=\infty$），由 2.1.3 P2 用有限个盒之并 $U_j$ 逼近使 $\sum|a_j|m(E_j\triangle U_j)<\varepsilon/3$；所得阶梯函数 $\varphi=\sum a_j\mathbf 1_{U_j}$ 满足 $\int|f-\varphi|<\varepsilon$。连续函数版本（$C_c$ 稠密）在 3.3.3。`] },
          {
            kind: 'build',
            label: 'P5',
            title: '不定积分是有符号测度',
            paras: [r`$f\in L^1(\mu)$ 时 $\nu(E)=\int_Ef\,d\mu$ 是有限有符号测度（可数可加由 DCT，支配 $|f|$），其 Hahn 正集可取 $\{f\ge0\}$，Jordan 分解为 $\nu^\pm(E)=\int_Ef^\pm$，全变差 $|\nu|(E)=\int_E|f|$；且 $\mu(E)=0$ 推出 $\nu(E)=0$，$\varepsilon$–$\delta$ 形式即 3.1.2A T4。这是 2.2.3 的第一个带密度的例，3.3.0 命名为 $\nu\ll\mu$，3.3.1 证明反向（每个绝对连续的有符号测度都是这种形式）。`] },
          {
            kind: 'example',
            label: 'E1–E3',
            title: '三类边界',
            paras: [r`绝对可积但无界（$x^{-1/2}$ 于 $(0,1)$）；局部可积非全局可积（$1/(1+|x|)$）；正负部均无限（$\sin x/x$；计数测度下的 $(-1)^n/n$）。`] },
          {
            kind: 'example',
            label: 'E4',
            title: '推前积分公式',
            paras: [r`$\int_Yf\,d(T_*\mu)=\int_Xf\circ T\,d\mu$ 按指标（定义）、简单（线性）、非负（MCT）、可积（正负部）四阶回填 2.3.1 的欠账。用途：2.3.4 P2 给 $\int_0^1F(x)\,dx=\int F\circ\beta\,dP$，把 $[0,1]$ 上的积分变成掷硬币空间上的积分。`] },
          {
            kind: 'example',
            label: 'E5',
            title: '$|\\int f|\\le\\int|f|$ 的等号',
            paras: ['等号成立当且仅当 $f$ 的辐角 a.e. 常数（在 $\\{f\\ne0\\}$ 上）；极分解在 3.3.1 兑现。'],
          },
          {
            kind: 'example',
            label: 'E6',
            title: '一个复值积分',
            paras: [r`$\int_0^\infty e^{-x}e^{ix}\,dx=1/(1-i)=(1+i)/2$，Fourier 变换的第一个具体值（由 DCT 对 $\int_0^R$ 取极限，或直接由原函数），3.2.3 用 Fourier 变换作参数积分例。`] },
          {
            kind: 'example',
            label: 'E7',
            title: 'Riemann–Lebesgue 引理',
            paras: [r`$f\in L^1(\mathbb R)$ 则 $\int f(x)\sin(nx)\,dx\to0$（对 $e^{inx}$ 同样）。证明：取阶梯 $\varphi$ 使 $\|f-\varphi\|_1<\varepsilon$（P4），则 $|\int f\sin(nx)|\le|\int\varphi\sin(nx)|+\varepsilon$，前者由 3.1.2A E4 趋零。这是“稠密性传递”的标准形式：结论对稠密类成立且两边都对 $L^1$ 范数连续（1.4.1 P1 的精神）。`] },
          {
            kind: 'example',
            label: 'E8',
            title: '积分对定义域的连续性',
            paras: [r`$f\in L^1$ 时 $E_n\uparrow E$ 或 $E_n\downarrow E$ 都给 $\int_{E_n}f\to\int_Ef$（DCT 或 P5 的测度连续性）；特别地 $\int_{-R}^Rf\to\int_{\mathbb R}f$。反常积分与 Lebesgue 积分在绝对可积时一致的一半（3.1.6 P2）。`] },
          {
            kind: 'counter',
            label: 'C1–C2',
            title: '两个边界',
            paras: [r`$\int_{-R}^R x\,dx=0$ 对所有 $R$，但 $x\notin L^1(\mathbb R)$：对称极限不是积分（“主值”不是 Lebesgue 积分）。$\mathbf 1_{\mathbb Q}$ 处处不连续，故不能用连续阶梯逼近，但 P4 的阶梯逼近仍成立（它 a.e. 等于 $0$）：P4 逼近的是 $L^1$ 元素，不是逐点值。`] },
          { kind: 'pitfall', paras: ['（一）在 $\\int f^+=\\int f^-=\\infty$ 时写 $\\int f=0$。（二）复值积分的定义要求 $|f|$ 可积，不是 $u,v$ 各自“有定义”。（三）P4 中忘记检查非零值层测度有限。（四）以为 Riemann–Lebesgue 引理由 DCT 得到。'] },
          { kind: 'link', paras: ['3.1.4、3.1.6、3.2.0、3.3.0（P5）、3.3.3（P4 的 $C_c$ 版本）、第四章 Fourier 分析（E7）。'] },
          { kind: 'deps', paras: ['3.0.1、3.1.1、3.1.2、3.1.2A；2.1.3、2.2.3、2.3.1、2.3.4；1.1.1、1.4.1。'] },
          { kind: 'scope', paras: ['约 11 页。'] },
        ],
      },
      {
        number: '3.1.4',
        title: 'Egorov–Lusin 与“几乎一致”模型',
        status: '新增',
        label: 'subsec:3-1-4-egorov-lusin',
        pages: 12,
        blocks: [
          { kind: 'anchor', paras: ['新增文件 sec-03-01b-egorov-lusin.tex，置于原 3.1.3 之后、3.1.5 之前。依赖有限测度的从上连续性（2.1.3A）、有限 Radon 正则性（2.2.2）、简单逼近（3.0.1）与一致极限保持连续（1.3.1A）。'] },
          { kind: 'recall', paras: ['第一章：1.3.1A（三种收敛、Dini P2、P1）、1.3.1（Tietze、E4）、1.3.0（P2 截断）、1.2.2A（Cantor 函数连续）。第二章：2.1.3（正则性、a.e.）、2.1.3A（P2、P4）、2.2.2（Radon）。本章：3.0.1（D3、E5）。'] },
          {
            kind: 'motivation',
            paras: [
              r`两个问题。第一，a.e. 收敛能否在大集合上升级为一致收敛？Dini 定理（1.3.1A）用紧性做到了这件事，条件是单调加极限连续；Egorov 定理用有限测度做到它，代价是删去一个测度任意小的集合。第二，可测函数在大集合上是否连续？Dirichlet 函数 $\mathbf 1_{\mathbb Q}$ 处处不连续，但用总长小于 $\varepsilon$ 的开集 $U$ 盖住有理数后，它在闭集 $[0,1]\setminus U$ 上恒为零——这是 Lusin 定理的手算版本，一般证明只是把这一步交给 Radon 内正则性与简单逼近。两条定理是 Littlewood 第二、第三原理（贯穿原理 D）。`,
            ],
          },
          {
            kind: 'build',
            label: 'D1, T1, P1',
            title: '几乎一致收敛与 Egorov',
            paras: [r`D1：对每个 $\varepsilon$ 存在 $\mu(E_\varepsilon)<\varepsilon$ 使 $f_n\to f$ 在 $E_\varepsilon^c$ 上一致；异常集可随 $\varepsilon$ 变化，但固定 $\varepsilon$ 后控制整个尾列。T1（Egorov）：$\mu(X)<\infty$、$f_n\to f$ a.e. 且 a.e. 有限，则几乎一致收敛。P1：几乎一致推出依测度与 a.e. 收敛（后者：取 $\varepsilon=1/k$ 的异常集之交为零集）；两者都不需有限测度。`] },
          {
            kind: 'build',
            label: 'T2',
            title: 'Lusin（Borel/Radon 版）',
            paras: [r`$X$ 局部紧 Hausdorff，$\mu$ 有限 Radon Borel 测度，$f$ Borel 可测 a.e. 有限，则对每个 $\varepsilon$ 存在紧集 $K$，$\mu(X\setminus K)<\varepsilon$ 且 $f|_K$ 连续。完成测度版需先取 Borel 代表（3.0.1 E5）再把差集（零测）从 $K$ 中去掉并重新内逼近；不在两种约定间无声切换。$\sigma$-有限版本：对 $\mathbb R^n$ 上的 Lebesgue 测度，用 $[-k,k]^n$ 逐块并把 $\varepsilon2^{-k}$ 分配给各块，得到闭集 $F$（未必紧）使 $m(F^c)<\varepsilon$、$f|_F$ 连续。`] },
          {
            kind: 'example',
            label: 'E1',
            title: '$x^n$ 的端点层',
            paras: ['全区间不一致；删去 $(1-\\delta,1]$ 后补集上的上确界为 $(1-\\delta)^n\\to0$。坏行为的空间位置被一个固定小集包住。'],
          },
          {
            kind: 'example',
            label: 'E2',
            title: 'Dirichlet 代表的手算 Lusin',
            paras: ['即动机中的构造，逐项验证 $K$ 紧、$m(K^c)<\\varepsilon$、$f|_K$ 连续（恒零）。Lusin 给大紧集上的连续限制，不给原代表的全空间连续性。'],
          },
          {
            kind: 'example',
            label: 'E3',
            title: '阶梯函数与 Cantor 函数',
            paras: ['阶梯函数只需删除跳跃点附近的小开区间；Cantor 函数本身连续，取 $K$ 为全空间。两例分别测试“需要删集”与“不必删集”，不把奇异性误当不连续。'],
          },
          {
            kind: 'example',
            label: 'E4',
            title: '可测函数是连续函数的 a.e. 极限',
            paras: [r`用 Lusin 加 Tietze（1.3.1 E4）取 $g_n\in C_c(\mathbb R^n)$ 与 $f$ 在测度 $<2^{-n}$ 的集合外相等（Tietze 延拓 $f|_K$，乘以 1.3.0 P2 的截断），Borel–Cantelli（2.1.3A P4）给 $g_n\to f$ a.e.。与 3.3.3 的 $C_c$ 稠密并列但结论不同：一个是 a.e. 收敛，一个是 $L^p$ 收敛。`] },
          {
            kind: 'example',
            label: 'E5',
            title: '逃逸列的局部修复',
            paras: ['在每个 $[-R,R]$ 上对逃逸列用 Egorov 成立；逐块异常集不能合成总测度任意小的全局异常集（C1）。'],
          },
          {
            kind: 'example',
            label: 'E6',
            title: 'Lusin 与 Riemann 可积的对照',
            paras: ['Thomae 函数在 $\\mathbb Q$ 上不连续而 a.e. 连续（3.1.6 意义）；Dirichlet 函数处处不连续但“Lusin 意义下几乎连续”。两种“几乎连续”不同：前者说函数本身的连续点多，后者说限制到大集合后连续。第一版把它们写在一起，本次分开。'],
          },
          {
            kind: 'counter',
            label: 'C1',
            title: '无限测度上的逃逸',
            paras: [r`$\mathbf 1_{[n,n+1]}$ 在 $\mathbb R$ 上逐点趋零；若 $m(E)<1$，每个 $[n,n+1]$ 都有点在 $E^c$ 中，于是 $\sup_{E^c}|f_n|=1$。有限测度假设的精确失效。`] },
          {
            kind: 'counter',
            label: 'C2',
            title: '依测度不推几乎一致',
            paras: ['3.1.5 的打字机序列依测度趋零但处处不收敛，而几乎一致收敛推出 a.e. 收敛（P1）。'],
          },
          {
            kind: 'counter',
            label: 'C3',
            title: '缺 Radon 正则性',
            paras: ['若可测集不能由紧集从内逼近，简单函数步骤即无法完成；正文写“缺少假设时本证明失效”，不虚构未经核验的病态空间。'],
          },
          {
            kind: 'proof',
            paras: [
              r`Egorov：清理零集；尾部坏集 $E_{N,k}=\bigcup_{n\ge N}\{|f_n-f|>1/k\}$ 关于 $N$ 递减且交空；有限测度给 $\mu(E_{N,k})\downarrow0$（2.1.3A P2，唯一使用有限测度处，与 Dini 证明中“递减闭集交空则有限步为空”并排写出：紧性换成有限测度）；预算：取 $N_k$ 使 $\mu(E_{N_k,k})<\varepsilon2^{-k}$，$E=\bigcup_kE_{N_k,k}$；统一尾指标：$x\notin E$、$n\ge N_k$ 时 $|f_n(x)-f(x)|\le1/k$，$N_k$ 不依赖 $x$。Lusin：有限值简单函数 $s=\sum a_j\mathbf 1_{E_j}$（值层不交）在紧集 $K_j\subset E_j$ 上——各 $K_j$ 在 $K=\bigcup K_j$ 中既开又闭（有限个不交紧集），故 $s|_K$ 连续；简单逼近 $s_n\to f$（3.0.1 D3 对 $f^\pm$）；Egorov 统一化得到一致收敛于紧集 $K_0$ 之外的小集；外正则去掉异常集得紧集 $K$；连续函数的一致极限连续（1.3.1A P1）。`,
            ],
          },
          { kind: 'pitfall', paras: ['（一）异常集依赖 $\\varepsilon$，不依赖 $n$；“对每个 $n$ 删一个小集”不是 Egorov。（二）Lusin 不说 $f$ 在 $K$ 的点处连续，只说 $f|_K$ 连续（E2 中 Dirichlet 函数在 $K$ 的每一点仍不连续）。（三）Egorov 需要有限测度（C1），Lusin 需要正则性（C3）。（四）“a.e. 连续”与“a.e. 等于连续函数”与“Lusin 意义几乎连续”三者不同（E6、2.1.3 E8）。'] },
          {
            kind: 'link',
            paras: ['1.3.1A Dini；2.2.2 正则性；1.3.1 Tietze；3.1.5 收敛模式；3.3.3 稠密性；第四章微分使用 Egorov/Lusin 时须重核有限或局部有限条件。'],
          },
          { kind: 'deps', paras: ['3.0.1、3.1.3；2.1.3、2.1.3A、2.2.2；1.2.2A、1.3.0、1.3.1、1.3.1A。'] },
          { kind: 'scope', paras: ['约 12 页。Egorov 与 Lusin 各只有一个主证明。'] },
        ],
      },
      {
        number: '3.1.5',
        title: '依测度收敛、一致可积与 Vitali',
        status: '前移',
        label: 'subsec:3-1-5-convergence-ui-vitali',
        origLabel: 'subsec:3-4-1',
        pages: 9,
        blocks: [
          { kind: 'anchor', paras: ['原 3.4.1 整体前移到 3.1.4 之后、3.2 之前，用 \\texttt{\\string\\insertedsubsection} 取显示号 3.1.5 并以 \\texttt{\\string\\subsectionalias} 保留旧 label；原稿中硬编码的“3.4.1”改用 \\texttt{\\string\\cref}。'] },
          { kind: 'recall', paras: ['3.1.1（Markov）、3.1.2（DCT）、3.1.2A（T4、E7）、3.1.4（P1）；2.1.3A（P4）；3.0.1 E7（Rademacher）。'] },
          {
            kind: 'motivation',
            paras: [
              r`打字机序列——依次取 $\mathbf 1_{[k2^{-n},(k+1)2^{-n}]}$，$n=1,2,\dots$，$k=0,\dots,2^n-1$——依测度趋零（第 $n$ 层的函数支撑测度 $2^{-n}$）但在每一点都无限经常取 $1$，处处不收敛；从每层取一个的子列却 a.e. 收敛，这是子列原理。尖峰与逃逸都积分有界而不一致可积，一个是高度尾，一个是空间尾。Vitali 定理精确刻画 $L^1$ 收敛为依测度收敛加一致可积（无限测度时再加 tight），它填上 3.1.2A E7 留的空槽。`,
            ],
          },
          {
            kind: 'build',
            label: 'D1–D3, T1–T2',
            title: '依测度、一致可积、tight、子列原理、Vitali',
            paras: [r`D1：$f_n\to f$ 依测度：对每个 $\eta$，$\mu(|f_n-f|>\eta)\to0$。D2：$\{f_n\}$ 一致可积：$\lim_{M\to\infty}\sup_n\int_{|f_n|>M}|f_n|=0$；有限测度时等价于 $L^1$ 有界加一致绝对连续（对每个 $\varepsilon$ 存在 $\delta$，$\mu(E)<\delta$ 蕴含 $\sup_n\int_E|f_n|<\varepsilon$）。D3：tight：对每个 $\varepsilon$ 存在有限测度集 $E$ 使 $\sup_n\int_{E^c}|f_n|<\varepsilon$。T1（子列原理）：依测度收敛列有 a.e. 收敛子列。T2（Vitali）：$f_n\to f$ 于 $L^1$ 当且仅当依测度收敛、一致可积、tight。`] },
          {
            kind: 'example',
            label: 'E1',
            title: '子列原理',
            paras: ['选 $n_k$ 使 $\\mu(|f_{n_k}-f|>2^{-k})<2^{-k}$，Borel–Cantelli（2.1.3A P4，或 2.1.3A E6 的判据）给 a.e. 收敛。'],
          },
          {
            kind: 'example',
            label: 'E2',
            title: '一致可积的两个判据',
            paras: [r`若 $\sup_n\int|f_n|^p<\infty$ 对某个 $p>1$，则一致可积：在 $\{|f_n|>M\}$ 上 $|f_n|\le M^{1-p}|f_n|^p$，故 $\int_{|f_n|>M}|f_n|\le M^{1-p}\sup_n\int|f_n|^p\to0$（不需要 Hölder）。若 $|f_n|\le g\in L^1$ 则一致可积（T4）。de la Vallée Poussin 判据若原稿有则保留为延伸。`] },
          {
            kind: 'example',
            label: 'E3',
            title: '弱大数律',
            paras: [r`$S_n=\sum_{k\le n}r_k$（3.0.1 E7），$\int S_n^2=n$（正交性），Markov 对 $S_n^2$ 给 $m(|S_n|>\varepsilon n)\le1/(\varepsilon^2n)\to0$：$S_n/n$ 依测度趋零。贯穿问题 A 的弱版本只需二阶矩；a.e. 版本在 3.2.4 需要四阶矩与 Borel–Cantelli。`] },
          {
            kind: 'example',
            label: 'E4',
            title: '收敛模式图廊',
            paras: ['一致 $\\Rightarrow$ 几乎一致 $\\Rightarrow$ a.e. 与依测度；$L^1\\Rightarrow$ 依测度（Markov）；有限测度时 a.e. $\\Rightarrow$ 几乎一致（Egorov）$\\Rightarrow$ 依测度；依测度 $\\Rightarrow$ 有 a.e. 子列。每条不成立的反向都由打字机、尖峰、逃逸或 $x^n$ 之一见证，以文字逐条写出，不画图。'],
          },
          {
            kind: 'counter',
            label: 'C1–C2',
            title: '尖峰与逃逸的不同修复',
            paras: ['尖峰缺一致可积，截断无效（$\\int_{f_n>M}f_n=1$ 当 $n>M$），需要支配或 UI；逃逸在有限测度子集上一切正常，缺的是 tight。'],
          },
          {
            kind: 'counter',
            label: 'C3',
            title: '$L^1$ 有界不推一致可积',
            paras: ['尖峰列 $L^1$ 有界（积分恒一）却不一致可积。一致可积是“$L^1$ 有界”的一致化，多出来的恰是高度尾的控制。'],
          },
          {
            kind: 'proof',
            paras: ['Vitali 充分性拆成三步：依测度坏集 $\\{|f_n-f|>\\eta\\}$ 测度小，用一致绝对连续控制其上的积分；好集上 $|f_n-f|\\le\\eta$，乘以有限测度集 $E$ 的测度；$E^c$ 上用 tight。三个误差预算各自独立。必要性由 T4 与 DCT 的结论得到。'],
          },
          { kind: 'pitfall', paras: ['（一）“积分有界”不是一致可积（C3）。（二）依测度收敛不推 a.e. 收敛（打字机），只推子列。（三）D2 的两个等价形式只在有限测度下等价。'] },
          { kind: 'link', paras: ['3.1.2A 的第四问在此兑现；3.2.4；3.3.2（$L^p$ 收敛推依测度）；第四章微分、BV 与卷积直接依赖本节。'] },
          { kind: 'deps', paras: ['3.0.1、3.1.1、3.1.2、3.1.2A、3.1.4；2.1.3A。'] },
          { kind: 'scope', paras: ['约 9 页。不依赖 RN、$L^p$ 对偶或 Bochner。'] },
        ],
      },
      {
        number: '3.1.6',
        title: 'Riemann 积分的回收：Lebesgue 判据与反常积分',
        status: '新增主题',
        label: 'subsec:3-1-6-riemann-recovered',
        pages: 8,
        blocks: [
          { kind: 'anchor', paras: ['置于 3.1.5 之后、3.2 之前。使用 3.0.1 的阶梯函数、1.2.3 的半连续包络、1.4.1 的振荡函数、2.1.3 的零测集与 3.1.2 的 DCT。'] },
          { kind: 'recall', paras: ['Analysis I：Darboux 上下和、上下积分、分割加细使上和递减下和递增、单调函数的跳跃可数、Dirichlet 判别。第一章：1.2.3（E3 上包络半连续）、1.4.1（E1 振荡函数）。第二章：2.1.1、2.1.3。本章：3.1.2（DCT）、3.1.3（E8、C1）。'] },
          {
            kind: 'motivation',
            paras: [
              '第二章开场开出的账单：哪些函数 Riemann 可积？现在可以回答：有界函数在 $[a,b]$ 上 Riemann 可积当且仅当它的不连续点集 Lebesgue 零测，此时两种积分相等。证明只需把 Darboux 上下和看成阶梯函数的 Lebesgue 积分，让分割加细，用有界收敛定理取极限。Dirichlet、Thomae 与胖 Cantor 集三个例在此闭环。',
            ],
          },
          {
            kind: 'build',
            label: 'D1, P1',
            title: '上下包络与振荡',
            paras: [r`$f^*(x)=\lim_{\delta\to0}\sup_{B(x,\delta)}f$，$f_*$ 对称定义；$f^*$ 上半连续、$f_*$ 下半连续（1.2.3 E3 的对偶形式），$f^*-f_*=\omega_f$（1.4.1 E1），$f$ 在 $x$ 连续当且仅当 $f^*(x)=f_*(x)$。$f^*$、$f_*$ Borel 可测（半连续函数的水平集开或闭）。`] },
          {
            kind: 'build',
            label: 'T1–T2',
            title: 'Lebesgue 判据与两种积分相等',
            paras: [r`取分割列 $P_k$ 逐步加细且网格趋零；上 Darboux 阶梯函数 $U_k$ 递减、下阶梯函数 $L_k$ 递增，在分点以外（可数集）$U_k\to f^*$、$L_k\to f_*$；有界收敛（DCT，支配 $\sup|f|$ 于有限区间）给 $\overline{\int}f=\int f^*$、$\underline{\int}f=\int f_*$；Riemann 可积当且仅当 $\int(f^*-f_*)=0$，即 $\omega_f=0$ a.e.（3.1.1 P4）。此时 $f_*\le f\le f^*$ 且 $f_*=f^*$ a.e. 给 $f$ Lebesgue 可测（完备性）且两积分相等。`] },
          {
            kind: 'build',
            label: 'P2',
            title: '反常积分',
            paras: ['绝对收敛的反常积分等于 Lebesgue 积分（对 $|f|$ 用 MCT，对 $f$ 用 3.1.3 E8）；条件收敛的反常积分不是 Lebesgue 积分，是一个极限过程的名字（3.1.3 C1 的对称极限同理）。'],
          },
          {
            kind: 'example',
            label: 'E1–E3',
            title: '三个例的闭环',
            paras: [r`Thomae 函数：不连续点集 $\mathbb Q$ 零测，可积，积分为零。Dirichlet：处处不连续，不可积，但 Lebesgue 积分为零。胖 Cantor 集的指标函数：不连续点集 $K$ 正测度，不可积，Lebesgue 积分为 $m(K)=1/2$——2.1.1 E3 的上和下界 $1/2$ 现在被识别为 $\int f^*=m(K)$。`] },
          {
            kind: 'example',
            label: 'E4',
            title: '单调函数',
            paras: ['不连续点至多可数（跳跃对应 2.3.3 的原子），故 Riemann 可积。'],
          },
          {
            kind: 'example',
            label: 'E5',
            title: '$\\sin x/x$',
            paras: [r`反常积分收敛（Dirichlet 判别或分部积分），但 $\int_0^\infty|\sin x/x|=\infty$（$\int_{k\pi}^{(k+1)\pi}|\sin x|/x\ge\frac{2}{(k+1)\pi}$，与调和级数比较）。3.1.2A E5 的极限 $\pi/2$ 不能由 DCT 得到。`] },
          {
            kind: 'example',
            label: 'E6',
            title: 'Arzelà 有界收敛定理',
            paras: ['Riemann 理论中的有界收敛定理（一致有界、逐点收敛到 Riemann 可积函数）现在是 DCT 的特例。Lebesgue 理论“解释”了 Riemann 理论中最难的定理。'],
          },
          {
            kind: 'example',
            label: 'E7',
            title: '密度的识别',
            paras: [r`$g$ 为 $C^1$ 非减时，2.3.3 的 $\mu_g((a,b])=g(b)-g(a)=\int_a^bg^\prime$（Riemann，微积分基本定理）$=\int_{(a,b]}g^\prime\,dm$（T2），故 $\mu_g=g^\prime\,dm$（2.2.1 唯一性）。2.3.3 E7 的 $g_*\mu_g=m$ 于是成为 $g_*(g^\prime\,dm)=m$，即一维换元的测度形态；2.4.0 E6 的欠账在此结清，3.3.0 命名 $g^\prime=d\mu_g/dm$。`] },
          {
            kind: 'counter',
            label: 'C1–C2',
            title: '两个边界',
            paras: ['Riemann 可积函数的逐点有界极限可以不 Riemann 可积（2.1.1 的双重极限）；Lebesgue 可积函数类对 a.e. 有界极限封闭——这是 Lebesgue 优于 Riemann 的精确表述。判据用 Lebesgue 零测而非 Jordan 零容量：$\\mathbb Q$ 零测但不零容量（2.1.1 D1）。'],
          },
          { kind: 'pitfall', paras: ['（一）“不连续点集零测”不是“a.e. 等于连续函数”（Dirichlet 满足后者不满足前者）。（二）以为每个反常积分都是 Lebesgue 积分（E5）。（三）T1 中把“在分点以外收敛”忘记，导致以为 $U_k\\to f^*$ 处处成立。'] },
          { kind: 'link', paras: ['2.1.1 闭环；1.4.1 与 1.2.3 回收；2.3.3、2.4.0 的欠账结清；第四章微积分基本定理预告。'] },
          { kind: 'deps', paras: ['3.0.1、3.1.1、3.1.2、3.1.3；2.1.1、2.1.3、2.2.1、2.3.3；1.2.3、1.4.1。'] },
          { kind: 'scope', paras: ['约 8 页。不进入 Henstock–Kurzweil 积分。'] },
        ],
      },
    ],
  },
];
