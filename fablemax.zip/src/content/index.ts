import { preface } from './preface';
import { revisionNotes } from './revision';
import { chapter1 } from './ch1';
import { chapter2 } from './ch2';
import { chapter3 } from './ch3';
import type { Chapter } from './types';

export { preface, revisionNotes };
export const chapters: Chapter[] = [chapter1, chapter2, chapter3];

export function countSubsections(ch: Chapter) {
  const all = ch.sections.flatMap((s) => s.subsections);
  return {
    total: all.length,
    kept: all.filter((s) => s.status === '保留并慢化' || s.status === '前移').length,
    added: all.filter((s) => s.status === '新增').length,
    topics: all.filter((s) => s.status === '新增主题').length,
    pages: all.reduce((a, s) => a + s.pages, 0),
    examples: all.reduce((a, s) => a + s.blocks.filter((b) => b.kind === 'example').length, 0),
    counters: all.reduce((a, s) => a + s.blocks.filter((b) => b.kind === 'counter').length, 0),
  };
}
