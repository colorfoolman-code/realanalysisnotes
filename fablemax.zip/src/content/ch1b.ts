import type { Section } from './types';

const r = String.raw;

export const ch1SectionsB: Section[] = [
  {
    number: '1.3',
    title: '连续函数：从局部构造到全局函数',
    lead: [
      '本二级节的主线问题是：怎样用有限个局部构造粘出一个全局连续函数，以及连续函数族何时有一致收敛子列、何时能一致逼近任意连续函数。新增的 1.3.0 用三个施工任务组织工具；新增主题 1.3.1A 把逐点、一致、紧集上一致三种收敛与 Dini 定理放在 Arzelà–Ascoli 之前，因为“紧性把逐点信息升级为一致信息”正是第三章 Egorov 定理与单调收敛定理的拓扑原型；1.3.3 加入 Bernstein 多项式的构造性证明，它的核心估计就是二项分布的 Chebyshev 不等式。',
    ],
    subsections: [
      {
        number: '1.3.0',
        title: '连续函数工具的三个施工任务',
        status: '新增',
        label: 'subsec:1-3-0-continuous-function-tool-ramp',
        pages: 9,
        blocks: [
          { kind: 'anchor', paras: ['插在原 1.2.3 之后、1.3.1 之前。它不取代原 1.3.1 的 LCH、单点紧化、Urysohn、Tietze 与 $C_c/C_0$ 结果，只给这些结果的第一批可算模型。'] },
          { kind: 'recall', paras: ['Analysis I/II：分段线性函数、$\\min$ 与 $\\max$ 保持连续、$e^{-1/t}$ 型函数在 $0$ 处无穷阶可微。基础拓扑：闭集、闭包、距离函数 $d(x,A)=\\inf_{a\\in A}d(x,a)$ 及其 $1$-Lipschitz 性（三角不等式）、$d(x,A)=0$ 当且仅当 $x\\in\\overline A$。'] },
          {
            kind: 'motivation',
            paras: [
              r`三个施工任务：分开两个不交闭集；把一个局部函数截成紧支撑；把有限个局部构造粘合。开场先在 $\mathbb R$ 上做第一个任务：$A=(-\infty,0]$，$B=[1,\infty)$，$u(x)=\min(1,\max(0,x))$。再问一般度量空间怎么办——答案是一个公式：$u(x)=d(x,A)/(d(x,A)+d(x,B))$，分母由 $A,B$ 不交且闭而非零（若 $d(x,A)=d(x,B)=0$ 则 $x\in\overline A\cap\overline B=\varnothing$）。于是度量空间的 Urysohn 引理是一行计算；一般拓扑空间没有距离函数，需要正规性与二进有理数构造，这就是 1.3.1 的难点所在。`,
              r`第二个问题：为什么要区分 $C_c$、$C_0$、$C_b$？因为第二章要用连续函数“观测”测度，而观测一个可能无限大的对象只能用紧支撑或在无穷远消失的函数；第三章的 $L^p$ 空间中也只有 $C_c$ 是稠密的。`,
            ],
          },
          {
            kind: 'build',
            label: 'D1–D2',
            title: '支撑与三个函数类',
            paras: [r`$\operatorname{supp}f=\overline{\{f\ne0\}}$，强调非零集本身未必闭。$C_b$ 有界连续，$C_c$ 紧支撑连续，$C_0$ 在无穷远消失（每个 $\{|f|\ge\varepsilon\}$ 紧）。紧空间上三者重合。`] },
          {
            kind: 'build',
            label: 'P1–P3',
            title: '三条命题',
            paras: [
              r`P1：紧 Hausdorff 空间正规（不交闭集有不交开邻域），证明两次用紧性、一次用 Hausdorff。P2（度量版局部截断）：$X$ 为局部紧度量空间，$K\subset U$、$K$ 紧、$U$ 开，则存在 $\varphi\in C_c(X)$，$0\le\varphi\le1$，$\varphi=1$ 于 $K$，$\operatorname{supp}\varphi\subset U$。证明全在本节内：先取相对紧开集 $U^\prime$ 使 $K\subset U^\prime\subset\overline{U^\prime}\subset U$（$K$ 的每点有相对紧开邻域含于 $U$，取有限个覆盖 $K$），令 $\delta=d(K,X\setminus U^\prime)>0$（紧集与不交闭集距离为正），$\varphi(x)=\max\bigl(0,1-d(x,K)/\delta\bigr)$；则 $\varphi$ 连续、在 $K$ 上为 $1$、支撑含于 $\overline{U^\prime}$ 故紧。一般 LCH 空间的版本（没有 $d$ 可用）留原 1.3.1，本节不使用。P3（度量版）：局部紧度量空间上 $C_c\subset C_0$（$\{|f|\ge\varepsilon\}$ 是紧支撑中的闭集）且 $C_c$ 在 $C_0$ 中一致稠密（取 $K=\{|f|\ge\varepsilon\}$ 与 P2 的 $\varphi$，则 $\|f-\varphi f\|_\infty\le\varepsilon$）；一般 LCH 版本在 1.3.1 用一般 P2 重复同一证明。`,
            ],
          },
          {
            kind: 'example',
            label: 'E1',
            title: '$\\mathbb R$ 上三函数',
            paras: [r`三角帽属于 $C_c$；$e^{-|x|}$ 属于 $C_0$ 但不属 $C_c$（支撑为全直线）；$\sin x$ 属于 $C_b$ 但不属 $C_0$（$\{|\sin x|\ge1/2\}$ 无界）。每个判断写支撑或阈值集 $\{|f|\ge\varepsilon\}$。`] },
          {
            kind: 'example',
            label: 'E2',
            title: '离散空间',
            paras: [r`无限离散空间 $\mathbb N$ 上 $C_b$、$C_c$、$C_0$ 分别是有界序列、有限支撑序列、趋零序列，即 $\ell^\infty$、$c_{00}$、$c_0$。P3 在此说：有限支撑序列在一致距离下稠密于趋零序列。3.3.2A 用同一组空间说明稠密子空间不完备。`] },
          {
            kind: 'example',
            label: 'E3',
            title: '开区间内的局部截断',
            paras: [r`$K=[1/3,2/3]\subset U=(1/4,3/4)\subset(0,1)$，写出分段线性帽函数 $\varphi$（在 $[1/4,1/3]$ 上从 $0$ 线性升到 $1$，在 $[2/3,3/4]$ 上线性降到 $0$）并逐项验证连续、取值、等于一的区域与支撑 $[1/4,3/4]\subset U$。`] },
          {
            kind: 'example',
            label: 'E4',
            title: '有限粘合',
            paras: [r`$[0,1]$ 上两个重叠开区间 $U_1=[0,2/3)$、$U_2=(1/3,1]$ 与两顶帽函数 $\eta_1,\eta_2$（各在自己的区间内为正、在区间外为零），令 $\psi_i=\eta_i/(\eta_1+\eta_2)$；先修正分母可能为零的问题（帽函数之和在覆盖上为正，需要 $\eta_i$ 在 $U_i$ 内处处为正），再看一般有限单位分解为何先要保证覆盖与正性。`] },
          {
            kind: 'example',
            label: 'E5',
            title: '度量空间的 Urysohn 公式与 McShane 延拓',
            paras: [r`用 $d(x,A)$ 的 Lipschitz 性给出分离函数（动机中的公式）。度量空间上的 Lipschitz 延拓：若 $f:A\to\mathbb R$ 满足 $|f(a)-f(b)|\le L\,d(a,b)$，则 $\tilde f(x)=\inf_{a\in A}\bigl(f(a)+L\,d(x,a)\bigr)$ 是全空间上的 $L$-Lipschitz 延拓（验证下确界有限、在 $A$ 上等于 $f$、Lipschitz 常数不变）。一般连续函数的 Tietze 延拓留原 1.3.1。这给 2.4.3 的 Lipschitz 延拓一个先例。`] },
          {
            kind: 'example',
            label: 'E6',
            title: '光滑帽函数',
            paras: [r`$\eta(x)=\exp(-1/(1-x^2))$ 于 $|x|<1$、其余为零，属于 $C_c^\infty(\mathbb R)$（Analysis II 的 $e^{-1/t}$ 例）。此处只说明 $C_c^\infty$ 非空，并指出 Stone–Weierstrass 给出的多项式逼近与光滑函数逼近是两回事；后者（磨光）在第四章。`] },
          {
            kind: 'example',
            label: 'E7',
            title: '三个区间上的单位分解',
            paras: [r`用 $U_1=(-1,1/2)$、$U_2=(0,1)$、$U_3=(1/2,2)$ 覆盖 $[0,1]$，帽函数 $\eta_i$ 取 $d(x,U_i^c)$，$\psi_i=\eta_i/\sum_j\eta_j$。学生手算 $x=1/4$ 与 $x=3/4$ 处的三个值，看到“每点只有有限多个非零项且和为一”。`] },
          {
            kind: 'counter',
            label: 'C1–C4',
            title: '四个边界',
            paras: [
              r`局部紧不等于紧（$\mathbb R$：每点有相对紧邻域，但覆盖 $(-k,k)$ 无有限子覆盖）；有界连续不等于无穷远消失（$\sin x$、常数 $1$）；支撑的闭包取在当前空间（$f(x)=x(1-x)$ 于 $(0,1)$ 的支撑是 $(0,1)$，在 $(0,1)$ 中闭但不紧）；缺正规性不能默用 Urysohn（Sorgenfrey 平面只引用技术档案，读者只需回答“哪一步需要分离闭集”）。`,
            ],
          },
          { kind: 'pitfall', paras: ['（一）把 $\\operatorname{supp}f$ 写成 $\\{f\\ne0\\}$ 而忘记取闭包。（二）$C_0$ 定义中的“$\\{|f|\\ge\\varepsilon\\}$ 紧”写成“有界”，在非 Euclidean 空间两者不同。（三）分母 $\\eta_1+\\eta_2$ 为零的点被忽略。（四）以为度量空间的 Urysohn 公式在一般拓扑空间也能写——那里没有 $d$。'] },
          {
            kind: 'link',
            paras: ['2.2.2 用 P2 的截断函数观测 Radon 测度；3.3.3 用 P2、P3 与 Lusin 证明 $C_c$ 在 $L^p$ 稠密；3.1.4 的连续延拓桥用 Tietze；2.4.3 用 E5 的 McShane 延拓；1.3.1 E5 证明 $C_0$ 完备。'],
          },
          { kind: 'deps', paras: ['1.2.0–1.2.1（紧性、Hausdorff 中紧集闭）、1.2.3（闭水平集）；先修课程（距离函数、分段线性函数）。'] },
          { kind: 'scope', paras: ['约 9 页。不新增 Riesz 表示、对偶空间、一般单位分解或流形语言。'] },
        ],
      },
      {
        number: '1.3.1',
        title: '局部紧空间、紧化与连续函数工具',
        status: '保留并慢化',
        label: 'subsec:1-3-1',
        origLabel: 'subsec:1-3-1',
        pages: 10,
        blocks: [
          { kind: 'anchor', paras: ['LCH、单点紧化、正规性、Urysohn、Tietze、截断、单位分解、稠密、完备全保留。Sorgenfrey 平面非正规长证移章末技术档案，原位置留一页陈述与回引。'] },
          { kind: 'recall', paras: ['基础拓扑：子空间、商与嵌入的基本语言、Hausdorff。Analysis II：一致收敛的 Cauchy 判据、一致极限保持连续性（1.3.1A 将重证）。1.3.0 的三类函数与 P1–P3。'] },
          {
            kind: 'motivation',
            paras: [
              r`单点紧化让“在无穷远消失”成为字面意义：$C_0(X)=\{f\in C(X_\infty):f(\infty)=0\}$。两个可算的例开场：$\mathbb N_\infty$ 上的连续函数恰是收敛序列；$\mathbb R_\infty$ 是圆周。随后的问题是：为什么 Radon 测度理论要在局部紧 Hausdorff 空间上做？因为只有在那里，1.3.0 的截断函数才足够多到能观测测度；$\mathbb Q$ 就不行（E3）。`,
            ],
          },
          {
            kind: 'build',
            label: 'D1–D2, T1–T2',
            title: '局部紧、单点紧化、Urysohn、Tietze',
            paras: ['局部紧：每点有紧邻域（Hausdorff 时等价于有相对紧开邻域基）。单点紧化 $X_\\infty$：$\\infty$ 的邻域是紧集的补。Urysohn：正规空间中不交闭集可由 $[0,1]$ 值连续函数分离。Tietze：正规空间闭子集上的有界连续函数可延拓为全空间有界连续函数且保持上确界。'],
          },
          {
            kind: 'example',
            label: 'E1–E2',
            title: '两个单点紧化',
            paras: [r`$\mathbb N_\infty$ 与收敛序列空间 $c$（$f$ 连续当且仅当 $f(n)\to f(\infty)$）；$\mathbb R_\infty\cong S^1$（球极投影，用 1.2.1 E4 验证同胚）。`] },
          {
            kind: 'example',
            label: 'E3',
            title: '$\\mathbb Q$ 不局部紧',
            paras: [r`$\mathbb Q$ 中任何闭球都不紧（含无极限的 Cauchy 列，如 $\sqrt2$ 的十进逼近）。说明为什么在 $\mathbb Q$ 上没有好的 Radon 测度理论，也预告 2.2.2 中“$\mathbb Q$ 上的计数测度不是 Radon 测度”。`] },
          {
            kind: 'example',
            label: 'E4',
            title: 'Tietze 的用途预告',
            paras: ['把闭集上的连续函数延拓到全空间再乘以 1.3.0 的截断函数，就得到 $C_c$ 函数。3.1.4 与 3.3.3 用它把 Lusin 定理得到的 $f|_K$ 变成 $C_c$ 函数；此处只演示 $K=[0,1]\\cup[2,3]$、$f$ 在两段上分别为常数 $0$ 与 $1$ 的显式延拓。'],
          },
          {
            kind: 'example',
            label: 'E5',
            title: '$C_0(X)$ 完备',
            paras: [r`$C_b(X)$ 在一致距离下完备（一致 Cauchy 列逐点收敛，极限有界且由 $\varepsilon/3$ 论证连续），$C_0(X)$ 是其中的闭子集（若 $f_n\to f$ 一致且 $f_n\in C_0$，取 $n$ 使 $\|f-f_n\|<\varepsilon/2$，则 $\{|f|\ge\varepsilon\}\subset\{|f_n|\ge\varepsilon/2\}$ 紧），故完备。这是本书允许的初等泛函接口，3.3.2A 直接回引。`] },
          {
            kind: 'counter',
            label: 'C1',
            title: 'Tietze 需要闭集',
            paras: [r`$f(x)=\sin(1/x)$ 在 $(0,1]$ 上连续有界，不能连续延拓到 $[0,1]$（1.0.1 E5）；$(0,1]$ 在 $[0,1]$ 中不闭。`] },
          {
            kind: 'proof',
            paras: ['单点紧化分别验证拓扑、Hausdorff（需局部紧）、紧；Urysohn 按“闭集邻域递进、嵌套闭包、按二进有理阈值定义函数、验证连续”四步；Tietze 标出迭代误差 $(2/3)^n$ 与一致收敛（E5 的完备性在此使用）。'],
          },
          { kind: 'pitfall', paras: ['（一）把“局部紧”理解为“紧的弱化版”而直接取有限子覆盖（1.3.0 C1）。（二）Urysohn 分离的是闭集，不是任意不交集。（三）Tietze 延拓不唯一。'] },
          { kind: 'link', paras: ['出口 1.3.1A、1.3.2、1.3.3、2.2.2、3.1.4、3.3.3、3.3.2A（E5）。'] },
          { kind: 'deps', paras: ['1.2.0–1.2.1、1.3.0；先修课程（一致收敛的 Cauchy 判据）。'] },
          { kind: 'scope', paras: ['共 10 页，核心 8 页、技术档案 2 页。'] },
        ],
      },
      {
        number: '1.3.1A',
        title: '函数列的三种收敛与 Dini 定理',
        status: '新增主题',
        label: 'subsec:1-3-1a-modes-of-convergence-dini',
        pages: 9,
        blocks: [
          { kind: 'anchor', paras: ['置于 1.3.1 之后、1.3.2 之前。使用 1.0.1 的量词、1.1.1 P0、1.2.0 的紧性与 1.3.0 的 $C_b$。'] },
          { kind: 'recall', paras: ['Analysis II：一致收敛的定义、一致极限保持连续性、一致收敛下极限与 Riemann 积分可交换、Weierstrass M-判别法、幂级数在收敛圆内紧集上一致收敛。本节重证前两条，以便标出假设使用点。'] },
          {
            kind: 'motivation',
            paras: [
              r`$x^n$ 在 $[0,1]$ 上逐点收敛到 $\mathbf 1_{\{1\}}$，极限不连续：逐点收敛不保持连续性。什么收敛保持连续性？一致收敛。什么时候逐点收敛自动升级为一致收敛？Dini 定理：紧、单调、极限连续。这是紧性第一次“把逐点信息升级为一致信息”，第三章的 Egorov 定理（有限测度把 a.e. 收敛升级为几乎一致收敛）与单调收敛定理（单调加非负给出积分交换）都是它的同类。`,
              r`第二个问题来自 Analysis II 的两条定理：“一致极限保持连续”与“一致收敛下积分与极限可交换”。它们都是 1.1.1 P0（Moore–Osgood）的特例：前者交换 $\lim_n$ 与 $\lim_{y\to x}$，后者交换 $\lim_n$ 与 Riemann 和网的极限。看出这一点后，第三章“控制收敛”要做的事就清楚了：把“一致”换成更弱的“被一个可积函数支配”。`,
            ],
          },
          {
            kind: 'build',
            label: 'D1',
            title: '三种收敛',
            paras: [r`逐点：$\forall x\,\forall\varepsilon\,\exists N$；一致：$\forall\varepsilon\,\exists N\,\forall x$；紧集上一致：对每个紧集 $K$ 在 $K$ 上一致。用 1.0.1 的量词树标出唯一交换了的位置。一致收敛等价于 $\sup_x|f_n(x)-f(x)|\to0$，即在 $C_b$ 的一致距离下收敛。`] },
          {
            kind: 'build',
            label: 'P1–P4',
            title: '四条命题',
            paras: [
              r`P1：一致极限保持连续性（$\varepsilon/3$，或 P0）。P2：Dini 定理——紧空间上 $f_n\downarrow f$ 逐点、$f_n,f$ 连续，则一致收敛；证明为：对 $\varepsilon>0$，闭集 $F_n=\{f_n-f\ge\varepsilon\}$ 递减且交空，紧性（1.2.1 E5）给有限步为空。P3：$C(K)$ 在一致距离下完备（1.3.1 E5 的特例）——第一个 Banach 空间实例，3.3.2A 直接回引。P4：Weierstrass M-判别法。`,
            ],
          },
          {
            kind: 'example',
            label: 'E1',
            title: '$x^n$ 的两个区间',
            paras: [r`在 $[0,1]$ 上极限不连续，Dini 失效；在 $[0,1/2]$ 上极限为零，单调递减，一致收敛（$\sup=2^{-n}$）。`] },
          {
            kind: 'example',
            label: 'E2',
            title: '$(1+x/n)^n\\to e^x$',
            paras: ['在每个紧区间 $[0,R]$ 上单调递增（二项展开逐项比较或对数凹性）且极限连续，Dini 给出紧集上一致收敛。这是 3.1.2 中 Gamma 函数极限例的拓扑一半。'],
          },
          {
            kind: 'example',
            label: 'E3',
            title: '尖峰列第一次出场',
            paras: [r`$f_n(x)=nx(1-x^2)^n$ 在 $[0,1]$ 上逐点趋零（$x=0$ 处恒零，$x>0$ 处指数衰减），但 $\int_0^1f_n=n/(2n+2)\to1/2$（Riemann 积分，换元 $u=1-x^2$）。逐点极限的积分不等于积分的极限；不一致收敛（最大值在 $x\approx1/\sqrt{2n}$ 处约为 $\sqrt{n/2e}$）。第三章 3.1.2 用它开场，并解释失败原因是 $\sup_nf_n$ 在 $0$ 附近像 $1/x$，不可积。`] },
          {
            kind: 'example',
            label: 'E4',
            title: '逃逸列第一次出场',
            paras: [r`取 1.3.0 E6 的帽函数 $\eta$，令 $g_n(x)=\eta(x-n)$。它逐点趋零，在每个紧集上一致趋零（紧集有界，$n$ 大后 $g_n$ 在其上恒零），但不一致收敛（$\sup g_n=\eta(0)$），且 $\int g_n$ 恒为常数。这是“紧集上一致收敛”的标准正例，也是“空间尾”的首次出场。`] },
          {
            kind: 'example',
            label: 'E5',
            title: '幂级数',
            paras: ['幂级数在收敛圆内的紧集上一致收敛（M-判别法），因此其和连续；3.1.2A 用它说明逐项积分的两条不同许可。'],
          },
          {
            kind: 'example',
            label: 'E6',
            title: '一致收敛与 Riemann 积分交换',
            paras: [r`若 $f_n\to f$ 于 $[a,b]$ 一致且各 $f_n$ Riemann 可积，则 $f$ 可积且 $\int f_n\to\int f$：$|\int f_n-\int f|\le(b-a)\sup|f_n-f|$。用 P0 的语言：Riemann 和关于 $n$ 一致收敛。3.1.2 与 3.1.6 把“一致”换成“支配”。`] },
          {
            kind: 'counter',
            label: 'C1',
            title: 'Dini 缺单调',
            paras: [r`滑动帽：$h_n(x)=\eta(n(x-1/n)\cdot)$ 形状的函数——把 $\eta$ 压缩到宽度 $1/n$、中心放在 $1/n$、高度恒为 $1$。逐点趋零（每个 $x>0$ 最终在支撑之外），极限连续，定义域 $[0,1]$ 紧，但不一致收敛，因为在每一点处函数值先升后降，单调性失效。`] },
          {
            kind: 'counter',
            label: 'C2',
            title: 'Dini 缺紧性',
            paras: [r`$(0,1)$ 上 $x^n$ 单调递减到连续极限 $0$，但 $\sup_{(0,1)}x^n=1$。`] },
          {
            kind: 'counter',
            label: 'C3',
            title: 'Dini 缺极限连续',
            paras: ['即 E1 的第一个区间。三个反例各删一条假设。'],
          },
          { kind: 'pitfall', paras: ['（一）以为逐点极限连续就足以一致收敛（C1）。（二）Dini 定理只对单调列成立，且单调性要逐点。（三）把“紧集上一致收敛”与“一致收敛”混用；在 $\\mathbb R$ 上它们不同（E4）。（四）E3 中以为“逐点极限为零”就能推出积分趋零。'] },
          {
            kind: 'link',
            paras: ['3.1.2 的 MCT 是 Dini 的积分同类；3.1.4 Egorov 的证明与 P2 同构（递减闭集列换成递减可测集列，紧性换成有限测度的从上连续性）；3.1.5 的收敛模式图廊以本节三种收敛为起点；1.3.2 需要“一致收敛子列”这一目标概念；1.3.3 E5 的 Bernstein 证明用一致连续。'],
          },
          { kind: 'deps', paras: ['1.0.1、1.1.1（P0）、1.2.0–1.2.1（紧性、E5）、1.3.0（帽函数）、1.3.1（E5）；先修课程（一致收敛、幂级数）。'] },
          { kind: 'scope', paras: ['约 9 页。不引入紧开拓扑的一般理论，只用度量版本。'] },
        ],
      },
      {
        number: '1.3.2',
        title: '等度连续与 Arzelà–Ascoli',
        status: '保留并慢化',
        label: 'subsec:1-3-2',
        origLabel: 'subsec:1-3-2',
        pages: 8,
        blocks: [
          { kind: 'anchor', paras: ['等度连续、逐点相对紧与 AA 原定理、证明、反例全部保留。度量紧域版本先行，一般紧 Hausdorff 版本后置。'] },
          { kind: 'recall', paras: ['Analysis I/II：中值定理（一致 Lipschitz 族）、Riemann 积分的基本估计。1.2.0 的全有界与对角子列、1.3.1A 的 $C(K)$ 完备。'] },
          {
            kind: 'motivation',
            paras: [
              r`$C[0,1]$ 的闭单位球不紧：$x^n$ 与 $\sin(nx)$ 都没有一致收敛子列。缺什么？1.2.0 说紧等于全有界加完备，$C[0,1]$ 完备（1.3.1A P3），所以缺的是全有界；等度连续加逐点有界正是把“在有限多个点上有限采样”扩成“在整个区间上有限采样”的条件——1.2.0 E6 中“尾部一致小”的函数空间版本。开场先在有限 $\delta$-网格上把点值控制扩成一致控制，这是证明的心脏。`,
            ],
          },
          {
            kind: 'build',
            label: 'D1–D2, T1',
            title: '等度连续、逐点有界、Arzelà–Ascoli',
            paras: ['族 $\\mathcal F$ 等度连续：$\\forall\\varepsilon\\,\\exists\\delta\\,\\forall f\\in\\mathcal F\\,\\forall x,y$，即 $\\delta$ 既不依赖 $x$ 也不依赖 $f$（1.0.1 的量词签名多了一层）。T1：紧度量空间 $K$ 上 $\\mathcal F\\subset C(K)$ 相对紧当且仅当等度连续且逐点有界。'],
          },
          {
            kind: 'example',
            label: 'E1',
            title: '一致 Lipschitz 族',
            paras: ['常数 $L$ 一致 Lipschitz 且一致有界的族等度连续；Euler 折线族就是这样的族，Peano 存在定理的框架只陈述。'],
          },
          {
            kind: 'example',
            label: 'E2',
            title: '积分算子给出的族',
            paras: [r`$k$ 在 $[0,1]^2$ 连续，$(Kf)(x)=\int_0^1k(x,y)f(y)\,dy$（Riemann 积分）。族 $\{Kf:\|f\|_\infty\le1\}$ 等度连续，因为 $k$ 一致连续：$|Kf(x)-Kf(x')|\le\sup_y|k(x,y)-k(x',y)|$。这是“紧算子”的第一个例，与 3.2.3 的参数积分、3.4.2 的 Schur 检验相连，但不发展算子论。`] },
          {
            kind: 'example',
            label: 'E3',
            title: '$C^1$ 有界族',
            paras: [r`$\{f\in C^1[0,1]:\|f\|_\infty+\|f'\|_\infty\le1\}$ 在 $C[0,1]$ 中相对紧（中值定理给一致 Lipschitz）。这是第四章 Rellich 型紧性的最简原型：控制导数换来紧性。`] },
          {
            kind: 'counter',
            label: 'C1–C3',
            title: '三种失败',
            paras: [r`$x^n$ 在 $1$ 附近失去等度连续（$x^n$ 在 $[1-1/n,1]$ 上从 $1/e$ 附近升到 $1$）；$\sin(nx)$ 振荡（在长度 $\pi/n$ 的区间内从 $-1$ 到 $1$）；常数列 $n$ 高度逃逸（等度连续但不逐点有界）。只留一个振荡族与一个高度逃逸族。`] },
          {
            kind: 'proof',
            paras: ['充分性按“有限网格（1.2.0 全有界）、有限点数据的对角子列（1.2.0 证明中的同一构造）、全空间误差（等度连续把网格点的控制扩到整个空间）”三步；必要性由全有界直接得到等度连续。'],
          },
          { kind: 'pitfall', paras: ['（一）等度连续的 $\\delta$ 必须同时对 $x$ 与 $f$ 统一。（二）“逐点有界”在等度连续加紧域下自动升级为一致有界，但单独不够。（三）AA 给的是“相对紧”，闭包才紧。'] },
          { kind: 'link', paras: ['出口函数族紧性、3.2.3 与 3.4.2；第四章 Rellich 型紧性作类比。'] },
          { kind: 'deps', paras: ['1.2.0（全有界、对角子列、Lebesgue 数）、1.3.1A（$C(K)$ 完备、一致收敛）；先修课程（中值定理）。'] },
          { kind: 'scope', paras: ['约 8 页。不扩 Banach 值 AA。'] },
        ],
      },
      {
        number: '1.3.3',
        title: 'Stone–Weierstrass：分离观测生成函数',
        status: '保留并慢化',
        label: 'subsec:1-3-3',
        origLabel: 'subsec:1-3-3',
        pages: 8,
        blocks: [
          { kind: 'anchor', paras: ['实、复、紧、LCH 版本及原证明例全部保留。'] },
          { kind: 'recall', paras: ['Analysis I：二项式定理与恒等式 $\\sum_k\\binom nkx^k(1-x)^{n-k}=1$、$\\sum_k(k/n-x)^2\\binom nkx^k(1-x)^{n-k}=x(1-x)/n$（可由对 $(x+y)^n$ 求导两次得到）；紧区间上连续函数一致连续。1.3.1A 的 Dini 定理。'] },
          {
            kind: 'motivation',
            paras: [
              r`多项式能一致逼近 $[0,1]$ 上任意连续函数。哪些操作是关键？只需能逼近 $|x|$（由此得到 $\max,\min$），再加上“分离点”。开场用一个显式迭代 $p_{n+1}(t)=p_n(t)+\tfrac12\bigl(t-p_n(t)^2\bigr)$、$p_0=0$ 证明 $\sqrt t$ 在 $[0,1]$ 上被多项式单调逼近——这正是 Dini 定理（1.3.1A）的一次使用。第二个开场是 Bernstein 的构造性证明（E5），它用一个概率论式的估计代替全部抽象论证。`,
            ],
          },
          {
            kind: 'build',
            label: 'D1–D2, T1',
            title: '分离点、格闭包、Stone–Weierstrass',
            paras: ['子代数 $\\mathcal A\\subset C(K,\\mathbb R)$ 分离点：任意 $x\\ne y$ 存在 $f\\in\\mathcal A$ 使 $f(x)\\ne f(y)$。格闭包引理：$\\mathcal A$ 的一致闭包对 $\\max,\\min$ 封闭。T1：紧 Hausdorff 空间上含常数、分离点的实子代数一致稠密；复版本加共轭封闭；LCH 上的 $C_0$ 版本把“含常数”换成“处处不同时为零”。'],
          },
          {
            kind: 'example',
            label: 'E1',
            title: '$|x|$ 的多项式逼近',
            paras: ['由上面的迭代得到 $\\sqrt{x^2}=|x|$ 在 $[-1,1]$ 上的一致逼近，格闭包引理由此出发。'],
          },
          {
            kind: 'example',
            label: 'E2',
            title: '三角多项式在圆周上稠密',
            paras: [r`复代数 $\{e^{ikx}\}$ 的线性包含常数、分离点、对共轭封闭。3.3.2B 用它得到三角系在 $L^2$ 中完备。`] },
          {
            kind: 'example',
            label: 'E3',
            title: '乘积型函数稠密',
            paras: [r`$[0,1]^2$ 上形如 $\sum_if_i(x)g_i(y)$ 的函数一致稠密（含常数、分离点：坐标函数）。3.2.0 与 3.2.1 中乘积型函数是 Fubini 最简单的正例，本例说明为什么“在乘积型函数上验证”常常足够。`] },
          {
            kind: 'example',
            label: 'E4',
            title: '$C_0(\\mathbb R)$ 中的 Hermite 型代数',
            paras: [r`$\{p(x)e^{-x^2}:p\text{ 多项式}\}$ 在 $C_0(\mathbb R)$ 中稠密（LCH 版本：分离点由 $xe^{-x^2}$、处处非零由 $e^{-x^2}$ 保证，且对乘法封闭需改为 $p(x)e^{-x^2}$ 的乘积 $pq\,e^{-2x^2}$——所以正确的代数是 $\{p(x)e^{-kx^2}\}$ 的线性包；正文按此修正陈述）。`] },
          {
            kind: 'example',
            label: 'E5',
            title: 'Bernstein 多项式：Weierstrass 定理的构造性证明',
            paras: [
              r`$B_nf(x)=\sum_{k=0}^nf(k/n)\binom nkx^k(1-x)^{n-k}$。对 $\varepsilon>0$，由一致连续取 $\delta$；把 $|f(x)-B_nf(x)|\le\sum_k|f(x)-f(k/n)|p_{n,k}(x)$ 按 $|k/n-x|<\delta$ 与 $\ge\delta$ 分成两部分，前者 $<\varepsilon$，后者 $\le2\|f\|_\infty\sum_{|k/n-x|\ge\delta}p_{n,k}(x)\le2\|f\|_\infty\cdot\frac{x(1-x)}{n\delta^2}\le\frac{\|f\|_\infty}{2n\delta^2}$。最后一步是“偏离均值超过 $\delta$ 的权重不超过方差除以 $\delta^2$”——它在 3.1.1 与 3.2.4 以 Markov/Chebyshev 不等式的名字重新出现，在 3.1.5 E3 与 3.2.4 中用于掷硬币的大数律。Weierstrass 定理与大数律是同一个估计。`,
            ],
          },
          {
            kind: 'counter',
            label: 'C1–C3',
            title: '三个失败代数',
            paras: [r`只含偶函数不能分离 $x,-x$；不含常数时（如 $x$ 生成的代数）不能逼近 $1$；圆盘代数中 $z$ 的多项式不能逼近 $\bar z$（缺共轭封闭；见证：$\int_0^{2\pi}\bar z\,z^k\,d\theta$ 型正交关系，只陈述）。`] },
          { kind: 'pitfall', paras: ['（一）忘记复版本需要共轭封闭（C3）。（二）“分离点”是对代数说的，不是对每个函数说的。（三）以为 Stone–Weierstrass 给出光滑逼近或 $L^p$ 逼近；它只给一致逼近，其它由稠密性传递（3.3.3）。'] },
          { kind: 'link', paras: ['3.3.3 的 $L^p$ 可分性（多项式到 $C[0,1]$ 到 $L^p$）；3.3.2B 的完备正交系；3.2.1 的乘积型函数；E5 与 3.1.1 Markov、3.2.4 Chebyshev 同源。'] },
          { kind: 'deps', paras: ['1.2.0–1.2.1（紧性、一致连续）、1.3.1（正规、LCH）、1.3.1A（Dini、一致收敛）；先修课程（二项恒等式）。'] },
          { kind: 'scope', paras: ['约 8 页。禁止新增谱、C*-代数或一般局部凸空间。'] },
        ],
      },
    ],
  },
  {
    number: '1.4',
    title: '可数性与完备性：何时序列已经足够',
    lead: [
      '本二级节回答两个问题：哪些“可数”是同一回事，哪些不是；完备性除了给 Cauchy 列极限以外还能回答什么具体问题。新增的 1.4.0 不画箭头图，而是让每条推出关系与每条不成立的反向关系都由一个具体空间见证，并加入第二章需要的 σ-紧。1.4.1 以“没有函数恰在有理点连续”开场，使 Baire 定理从一开始就是一个能回答具体问题的工具，并补上压缩映射原理与一致连续延拓这两条后文反复调用的命题。',
    ],
    subsections: [
      {
        number: '1.4.0',
        title: '四种可数性、σ-紧及其在度量空间中的汇合',
        status: '新增',
        label: 'subsec:1-4-0-countability',
        pages: 9,
        blocks: [
          { kind: 'anchor', paras: ['置于原 1.3.3 之后、1.4.1 之前。使用 1.0.2 的序列安全区、1.2.0 的全有界与 1.3.1 的局部紧。'] },
          { kind: 'recall', paras: ['Analysis I：$\\mathbb Q$ 可数且稠密、有理系数多项式可数、$0$–$1$ 序列不可数、连续统基数 $\\mathfrak c=2^{\\aleph_0}$ 与 $\\mathfrak c^{\\aleph_0}=\\mathfrak c$（只用后一条的结论）。基础拓扑：拓扑基、稠密、Lindelöf 未假设。'] },
          {
            kind: 'motivation',
            paras: [
              '1.0.2 说度量空间中序列足够，理由是每点有可数邻域基。可数还能落在哪些对象上？全空间的一个可数基；一个可数稠密集；每个开覆盖的一个可数子覆盖；可数个紧集的并。前四者在度量空间中除第一个外全部重合，在一般空间中分离。开场问题：完备的度量空间一定可分吗？不可数离散空间说不。紧的度量空间一定可分吗？是，理由是 1.2.0 的有限网集取可数并。$\\mathbb R^n$ 为什么在测度论中如此方便？因为它同时是第二可数、局部紧与 σ-紧的。',
            ],
          },
          {
            kind: 'build',
            label: 'D1–D6',
            title: '六个定义',
            paras: ['第一可数（每点有可数邻域基）、第二可数（全空间有可数基）、可分（有可数稠密集）、Lindelöf（每个开覆盖有可数子覆盖）各写清量词落在哪个对象上；σ-紧：可数个紧集之并；Polish 定义为可分且存在完备的兼容度量，标准 Borel 只保留功能定义，显式编码留 1.4.2 技术档案。'],
          },
          {
            kind: 'build',
            label: 'P1–P6',
            title: '六条命题',
            paras: ['P1 第二可数推出第一可数与 Lindelöf；P2 度量空间中可分推出第二可数（有理半径球）；P3 度量空间中 Lindelöf 推出可分（$1/n$ 球覆盖取可数子覆盖收集球心）；P4 紧度量空间可分（1.2.0 全有界，取 $1/n$-网集的可数并）；P5 第二可数空间的开集至多连续统多个（每个开集由可数基的一个子族决定），2.1.4 用来证明 Borel 集严格少于 Lebesgue 可测集；P6 局部紧 Hausdorff 加第二可数推出 σ-紧（可数基中闭包紧的成员覆盖全空间，取它们的闭包），2.2.2 用它得到 $\\mathbb R^n$ 上 Radon 测度的内正则。'],
          },
          {
            kind: 'example',
            label: 'E1',
            title: '$\\mathbb R^n$',
            paras: ['有理中心有理半径球给可数基；$\\mathbb Q^n$ 给可数稠密集；Euclidean 完备给 Polish；$[-k,k]^n$ 给 σ-紧。2.0.2 用这个可数基说明 Borel 集由有理端点区间生成。'],
          },
          {
            kind: 'example',
            label: 'E2',
            title: '不可数离散空间',
            paras: ['第一可数且完备；任何稠密集等于全空间故不可分；单点开集族迫使基不可数，也给出没有可数子覆盖的开覆盖；紧集是有限集，故不 σ-紧。一个空间同时阻断五条错误箭头。'],
          },
          {
            kind: 'example',
            label: 'E3',
            title: '同一拓扑的两个度量',
            paras: [r`$(0,1)$ 与 $\mathbb R$ 经 $x\mapsto\tan(\pi x-\pi/2)$ 同胚，所以 $(0,1)$ 有完备的兼容度量，是 Polish 的，尽管通常度量不完备。“可完全度量”不能只检查手头一个度量。`] },
          {
            kind: 'example',
            label: 'E4',
            title: '$C[0,1]$ 可分',
            paras: ['有理系数多项式可数，由 Weierstrass 定理（1.3.3）稠密。3.3.3 由此得到 $L^p[0,1]$ 可分。'],
          },
          {
            kind: 'example',
            label: 'E5',
            title: '$\\ell^\\infty$ 不可分',
            paras: [r`$0$–$1$ 序列有不可数多个，两两距离 $1$，任何稠密集必须在每个半径 $1/2$ 的球中有一点，故不可数。3.3.3 用同一论证证明 $L^\infty[0,1]$ 不可分（族 $\mathbf 1_{[0,t]}$）。`] },
          {
            kind: 'example',
            label: 'E6',
            title: 'Cantor 空间与 $\\{0,1\\}^{[0,1]}$',
            paras: ['柱集可数，故第二可数；有限支撑序列稠密；紧度量故完备；因此 Polish。对照 $\\{0,1\\}^{[0,1]}$：由 1.2.2 E6 它不是第一可数的（若 $\\mathbf 1$ 有可数邻域基，则可从 $A$ 中抽出收敛到 $\\mathbf 1$ 的序列）。'],
          },
          {
            kind: 'counter',
            label: 'C1–C4',
            title: '四条不成立的反向关系',
            paras: ['完备不推可分、第一可数不推第二可数（均由 E2）；Lindelöf 不推紧（$\\mathbb R$ 与覆盖 $(-n,n)$）；一般空间中可分不推第二可数（Sorgenfrey 线，只在延伸框陈述）。'],
          },
          { kind: 'pitfall', paras: ['（一）把“可分”读成“可数”；$\\mathbb R$ 可分但不可数。（二）第二可数是全局性质，第一可数是逐点性质。（三）σ-紧不推出局部紧（$\\mathbb Q$ 是可数个单点之并）。'] },
          { kind: 'link', paras: ['2.0.2 的 Borel 生成、2.1.3A 的 $\\sigma$-有限性（测度版 Lindelöf）、2.2.2 的 σ-紧与内正则、3.3.3 的可分性与不可分性、1.4.2 的 Polish 空间。'] },
          { kind: 'deps', paras: ['1.0.2、1.2.0（全有界）、1.2.2（E6）、1.3.1（局部紧）、1.3.3（Weierstrass）；先修课程（可数性、$\\mathbb Q$ 稠密）。'] },
          { kind: 'scope', paras: ['约 9 页。同一反例承担多条阻断时只讲一次。'] },
        ],
      },
      {
        number: '1.4.1',
        title: '完备度量空间与 Baire 范畴',
        status: '保留并慢化',
        label: 'subsec:1-4-1',
        origLabel: 'subsec:1-4-1',
        pages: 9,
        blocks: [
          { kind: 'anchor', paras: ['完备化、Baire、标量一致有界原型与 generic 例全部保留。次序为：完备化具体例与两条延拓命题；稠密开集与无处稠密集；Baire；应用。'] },
          { kind: 'recall', paras: ['Analysis I：$\\mathbb R$ 的完备性、Cauchy 列、Thomae 函数在无理点连续有理点不连续。基础拓扑：稠密、内部为空、$G_\\delta$（可数个开集之交）与 $F_\\sigma$ 在本节定义。'] },
          {
            kind: 'motivation',
            paras: [
              r`有没有函数恰在有理点连续？Thomae 函数恰在无理点连续，对称的问题看似同样简单，答案却是否定的。论证需要两步：任何函数的连续点集是 $G_\delta$ 集；$\mathbb Q$ 不是 $G_\delta$ 集。第二步就是 Baire 定理。开场把这个问题完整解决，完备性从此不只是“Cauchy 列有极限”。`,
              r`第二个问题：一个只在稠密子集上定义的一致连续函数能否唯一延拓？例如 $2^x$ 先在 $\mathbb Q$ 上定义，再延拓到 $\mathbb R$。答案是能，且只用完备性。这条命题在第三章反复出现——先在稠密的简单函数或 $C_c$ 函数上定义或验证，再延拓到 $L^p$。`,
            ],
          },
          {
            kind: 'build',
            label: 'D1–D3, T1',
            title: '无处稠密、第一纲、Baire 定理',
            paras: ['无处稠密：闭包无内点。第一纲：可数个无处稠密集之并。Baire 定理：完备度量空间中可数个稠密开集之交稠密；等价地，完备度量空间不是第一纲的。'],
          },
          {
            kind: 'build',
            label: 'P1',
            title: '一致连续映射的延拓',
            paras: [r`$D\subset X$ 稠密，$Y$ 完备，$f:D\to Y$ 一致连续，则 $f$ 唯一延拓为 $X\to Y$ 的一致连续映射。证明：对 $x\in X$ 取 $D$ 中序列 $d_n\to x$，一致连续把 Cauchy 列映成 Cauchy 列，完备取极限；一致连续性保证极限与序列选择无关；延拓后的一致连续性用同一个 $\delta$。3.3.3 E3、3.3.2B 与第四章使用。`] },
          {
            kind: 'build',
            label: 'P2',
            title: '压缩映射原理',
            paras: [r`完备度量空间上的压缩映射 $T$（$d(Tx,Ty)\le q\,d(x,y)$，$q<1$）有唯一不动点，且对任何初值迭代 $T^nx_0$ 收敛到它，误差 $d(T^nx_0,x^*)\le q^n d(x_0,Tx_0)/(1-q)$。证明用几何级数证明迭代列是 Cauchy 列。2.4.1 的逆函数定理由它证明；此处先用一维例 $T(x)=\cos x$ 于 $[0,1]$ 演示。`] },
          {
            kind: 'example',
            label: 'E1',
            title: '连续点集是 $G_\\delta$',
            paras: [r`振荡函数 $\omega_f(x)=\lim_{\delta\to0}\sup\{|f(y)-f(z)|:y,z\in B(x,\delta)\}$，集合 $\{\omega_f<1/n\}$ 开，连续点集为其交。$\omega_f$ 在 3.1.6 Lebesgue 判据中是主角；1.0.1 E5 的 $\sin(1/x)$ 在 $0$ 处 $\omega_f=2$。`] },
          {
            kind: 'example',
            label: 'E2',
            title: '$\\mathbb Q$ 不是 $G_\\delta$',
            paras: [r`若 $\mathbb Q=\bigcap U_n$，则 $\mathbb R$ 是可数个无处稠密集（$U_n^c$ 是闭且无内点，因为 $U_n\supset\mathbb Q$ 稠密；再加单点 $\{q\}$）的并，与 Baire 矛盾。`] },
          {
            kind: 'example',
            label: 'E3',
            title: '完备化的两个具体例',
            paras: [r`$\mathbb Q$ 的完备化是 $\mathbb R$；预告而不使用：$(C[0,1],\int|f-g|)$ 的完备化将在 3.3.2 与 3.3.3 之后被识别为 $L^1[0,1]$。此处只让读者知道第三章的函数空间是本节抽象完备化的具体实现。`] },
          {
            kind: 'example',
            label: 'E4',
            title: 'Baire 与 Cantor 交定理',
            paras: ['Baire 定理的证明是 1.2.1 E5 在完备空间中的版本：紧集换成直径趋零的闭球，紧性换成完备性。'],
          },
          {
            kind: 'example',
            label: 'E5',
            title: '两个应用保留',
            paras: ['标量一致有界原型（逐点有界的连续函数族在某个开集上一致有界）为核心；处处连续无处可微函数的 generic 存在性保留为延伸例。'],
          },
          {
            kind: 'example',
            label: 'E6',
            title: '完备但不紧的球的嵌套',
            paras: [r`$\mathbb R$ 中闭球 $[n,\infty)$ 型的递减闭集交为空——Baire 与 Cantor 交定理都要求直径趋零或紧；这个例把两条定理的假设并排。`] },
          {
            kind: 'counter',
            label: 'C1',
            title: '缺完备性',
            paras: ['在 $\\mathbb Q$ 中可数个单点覆盖全空间，每个单点无处稠密；完备性在“取交点”一步使用。'],
          },
          {
            kind: 'proof',
            paras: ['Baire 按选初球、递归缩球（每步进入下一个稠密开集并把半径减半）、半径趋零、完备取交点、落入全部稠密开集五步。'],
          },
          { kind: 'pitfall', paras: ['（一）Baire 定理说的是“稠密开集”的交，不是“稠密集”的交（$\\mathbb Q$ 与无理数都稠密，交为空）。（二）第一纲（拓扑上小）与零测（测度上小）不同，3.2.4 E5 给出一个测度为 $1$ 的第一纲集。（三）P1 中若只有连续而非一致连续，延拓可能不存在（$\\sin(1/x)$）。'] },
          { kind: 'link', paras: ['2.0.2 的 $G_\\delta$ 与 $F_\\sigma$；3.1.6 的振荡函数；3.2.4 中“测度大与范畴大不同”的对照；3.3.2 的完备性；2.4.1 用 P2；3.3.3、3.3.2B 用 P1。'] },
          { kind: 'deps', paras: ['1.0.1（正确否定、Cauchy 量词）、1.2.0（完备）、1.2.1（E5）；先修课程（Thomae 函数、几何级数）。'] },
          { kind: 'scope', paras: ['约 9 页。不扩一般一致有界、开映射或闭图定理。'] },
        ],
      },
      {
        number: '1.4.2',
        title: '可分性、Polish 与标准 Borel',
        status: '保留并慢化',
        label: 'subsec:1-4-2',
        origLabel: 'subsec:1-4-2',
        pages: 7,
        blocks: [
          { kind: 'anchor', paras: ['所有定义、例、编码证明与原图表保留；标准 Borel 显式编码移章末技术档案。'] },
          { kind: 'recall', paras: ['1.4.0 的 Polish 定义、1.2.2 P1 的可数积度量、1.4.0 E3 的“同拓扑不同度量”技巧。'] },
          {
            kind: 'motivation',
            paras: ['为什么后两章偏爱 Polish 空间？三个可以具体说出的理由（此处只作预告，不作证明）：Borel 集由可数信息编码（2.0.2）；有限 Borel 测度自动由紧集从内逼近（Ulam 定理，2.2.2 证明）；测度由可数多个事件的值唯一决定（2.2.0 的唯一性）。本节的任务只是给出足够多的 Polish 空间与足够多的非例。'],
          },
          {
            kind: 'build',
            label: 'P1–P3',
            title: '三条封闭性',
            paras: [r`Polish 空间的可数积 Polish（1.2.2 P1 的度量，完备性逐坐标）；闭子空间 Polish；开子空间 Polish（对开集 $U$ 用度量 $d'(x,y)=d(x,y)+|1/d(x,U^c)-1/d(y,U^c)|$，它与 $d$ 在 $U$ 上诱导同一拓扑且完备——1.4.0 E3 技巧的一般形式）。$G_\delta$ 子空间 Polish 只陈述。`] },
          {
            kind: 'example',
            label: 'E1–E4',
            title: '典型 Polish 空间',
            paras: [r`$\mathbb R^n$ 及其闭子集；可数积（Cantor 空间、Baire 空间 $\mathbb N^{\mathbb N}$、Hilbert 立方体）；$(0,1)$ 与无理数集（后者是 $\mathbb R$ 的 $G_\delta$ 子集）；$C[0,1]$（可分由 1.4.0 E4，完备由 1.3.1A P3）。`] },
          {
            kind: 'counter',
            label: 'C1–C2',
            title: '两个非例',
            paras: [r`不可数离散空间：完备但不可分。$\mathbb Q$：可分但不可完全度量（它是可数个单点之并，若有完备兼容度量则与 Baire 矛盾——1.4.1 的又一次使用）。`] },
          {
            kind: 'proof',
            paras: ['可数积的完备度量按定义权重、证明同拓扑、Cauchy 坐标化、拼回极限四步。'],
          },
          { kind: 'pitfall', paras: ['（一）“Polish”是拓扑性质，检查一个度量不完备不能否定它（$(0,1)$）。（二）$\\mathbb Q$ 可分、可度量、σ-紧，却不 Polish。'] },
          { kind: 'link', paras: ['2.2.2 的 Ulam 定理；第二章可测结构；标准 Borel 只作为可测同构接口。'] },
          { kind: 'deps', paras: ['1.2.2（P1）、1.4.0、1.4.1（Baire）。'] },
          { kind: 'scope', paras: ['共 7 页，核心 5 页、技术档案 2 页。'] },
        ],
      },
      {
        number: '1.4.3',
        title: '选择原则与可构造替代',
        status: '保留并慢化',
        label: 'subsec:1-4-3',
        origLabel: 'subsec:1-4-3',
        pages: 5,
        blocks: [
          { kind: 'anchor', paras: ['ZF、CC、DC、UFL、AC 比较及原证明评注全部保留；主线改为按本书实际调用逐条说明。'] },
          { kind: 'recall', paras: ['1.1.3 陈述的 Zorn 引理；本节定义可数选择（CC）、依赖选择（DC）、超滤子引理（UFL）并陈述 AC 与 Zorn 等价。'] },
          {
            kind: 'motivation',
            paras: ['本章哪些证明用了选择？闭包的邻域网（1.1.1 E1）与网刻画连续性的反设造网；从可数基选代表与 Lindelöf 的证明（1.4.0，可数选择）；序列紧证明中的递归选择（1.2.0，依赖选择）；超滤子延拓（1.1.3，Zorn）；一般 Tychonoff（1.2.2，等价于 AC）。第二章 2.1.4 的不可测集也用选择公理，并且没有它“所有子集可测”是一致的（Solovay，只陈述）。于是“为什么 $\\sigma$-代数不是幂集”与选择公理直接挂钩。'],
          },
          {
            kind: 'example',
            label: 'E1',
            title: '可构造替代',
            paras: ['度量紧性用对角法替代超滤子；可数积用显式积度量；有限空间直接枚举；2.3.4 的掷硬币测度完全不用选择；1.2.2A 的全部构造是显式的。'],
          },
          {
            kind: 'example',
            label: 'E2',
            title: '本章的选择账本',
            paras: ['1.1.1 闭包刻画：一般空间用 AC，第一可数空间用 CC；1.2.0 序列紧推出全有界：DC；1.4.0 P2、P3：CC；1.1.3 自由超滤子：UFL；1.2.2 一般 Tychonoff：AC；其余核心证明不用选择。'],
          },
          {
            kind: 'counter',
            label: 'C1',
            title: '“正文没写 Zorn”不等于没有选择',
            paras: ['逐次选择可隐藏可数选择或依赖选择，必须登记；“对每个 $n$ 取一个 $x_n$ 使得……”就是一次可数选择。'],
          },
          { kind: 'pitfall', paras: ['（一）以为避免 Zorn 就避免了选择。（二）以为选择公理只影响“病态”结果；1.4.0 P3 这样温和的命题也用了可数选择。'] },
          { kind: 'link', paras: ['汇总 1.1.3、1.2.2、1.4.0–1.4.2；出口 2.1.4。'] },
          { kind: 'deps', paras: ['1.1.1、1.1.3、1.2.0、1.2.2、1.4.0。'] },
          { kind: 'scope', paras: ['共 5 页，核心 3 页、延伸 2 页。不扩集合论模型或独立性证明。'] },
        ],
      },
    ],
  },
];
