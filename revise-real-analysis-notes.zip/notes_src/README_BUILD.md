# 编译说明

本源码包包含全书第 1--7 章，并已合入完成修订的第 1 章、第 2 章与第 3 章；不附带字体文件。

第 1--3 章已统一修订术语、证明与例子，并保留原有编号和交叉引用。第 2 章包括测度构造、正则性、乘积与推前测度以及 Euclidean 体积；第 3 章包括 Lebesgue 积分、乘积积分、换元、Radon--Nikodym 定理、$L^p$ 空间、对偶与向量值积分。

建议环境：TeX Live（含 XeLaTeX、latexmk、Fandol 与 Latin Modern 字体）。在源码根目录运行：

```bash
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

如需清理编译产物：

```bash
latexmk -C
```
